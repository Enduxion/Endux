#pragma once
#include <SFML\Graphics.hpp>
#include <SFML\Audio.hpp>
#include <SFML\Window.hpp>
#include <SFML\Network.hpp>
#include <SFML\System.hpp>

#include <vector>
#include <cstdlib>
#include <ctime>
#include <sstream>

class Snake
{
private:
	sf::RenderWindow* window;
	sf::VideoMode videoMode;
	sf::Event ev;
	sf::Font font;
	sf::Text text;
	sf::SoundBuffer buffer;
	sf::Sound sound;

	float X, Y, posX, posY;
	int score, tailLen;
	bool gameOver;
	unsigned colorTail, colorTail2, colorTail3;

	sf::RectangleShape head;
	sf::RectangleShape fruit;
	std::vector<sf::RectangleShape>tail;

	sf::RectangleShape background1;

	enum Direction {STOP = 0, LEFT, RIGHT, UP, DOWN};
	Direction dir;

	void initVar();
	void initWindow();
	void initRect();
	void initText();
	void initFont();
public:
	//Cons && Des

	Snake();
	virtual ~Snake();

	//Function
	void run();
	void update();
	void render();
	void pollEvent();
	void fruitSpawn();
	void input();
	void logic();
	void setDirection();
	void updateText();
	void gameQuit();
	void collision();
	sf::RectangleShape makeTail();
};

