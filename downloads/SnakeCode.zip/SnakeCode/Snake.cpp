#include "Snake.h"

//Initialisation
void Snake::initVar()
{
	srand(static_cast<unsigned>(time(NULL)));
	this->window = nullptr;
	this->tailLen = 0;
	this->score = 0;
	this->dir = STOP;
	this->gameOver = false;
}

void Snake::initWindow()
{
	this->videoMode.width = 620;
	this->videoMode.height = 620;
	this->window = new sf::RenderWindow(videoMode, "Snake", sf::Style::Close | sf::Style::Titlebar);
	this->window->setFramerateLimit(10);
	this->window->setVerticalSyncEnabled(false);
}

void Snake::initRect()
{
	//background
	this->background1.setFillColor(sf::Color(0, 255, 0, 34));
	this->background1.setSize(sf::Vector2f(580.f, 580.f));
	this->background1.setPosition(sf::Vector2f(20.f,20.f));
	this->background1.setOutlineColor(sf::Color(0,255,0));
	this->background1.setOutlineThickness(20.f);

	this->head.setSize(sf::Vector2f(20.f, 20.f));
	this->X = static_cast<float>(this->window->getSize().x / 2) - (this->head.getSize().x / 2.f);
	this->Y = static_cast<float>(this->window->getSize().y / 2) - (this->head.getSize().y / 2.f);
	this->head.setPosition(this->X, this->Y);
	this->head.setFillColor(sf::Color(0,0,255));

	this->fruit.setSize(sf::Vector2f(20.f, 20.f));
	this->fruit.setFillColor(sf::Color(255, 0, 0));
	this->fruitSpawn();

	this->colorTail = 255;
	this->colorTail2 = 0;
	this->colorTail3 = 0;
}

void Snake::initFont()
{
	this->font.loadFromFile("./Font/KoHo.ttf");
}

void Snake::initText()
{
	this->text.setFont(this->font);
	std::stringstream ss;
	ss << "Score: " << this->score;
	this->text.setCharacterSize(18);
	this->text.setPosition(sf::Vector2f(21.f, 21.f));
	this->text.setString(ss.str());
}

//functions
void Snake::pollEvent()
{
	while (this->window->pollEvent(ev))
	{
		switch (ev.type)
		{
		case sf::Event::Closed:
			window->close();
			break;
		}
	}
}

void Snake::updateText()
{
	std::stringstream ss;
	ss << "Score: " << this->score;
	this->text.setString(ss.str());
}

void Snake::setDirection()
{
	switch (this->dir)
	{
	case LEFT:
		this->X -= 20.f;
		break;
	case RIGHT:
		this->X += 20.f;
		break;
	case DOWN:
		this->Y += 20.f;
		break;
	case UP:
		this->Y -= 20.f;
		break;
	}
	this->head.setPosition(sf::Vector2f(this->X, this->Y));
}

void Snake::collision()
{
	for (auto& e : tail)
	{
		if (this->head.getGlobalBounds().intersects(e.getGlobalBounds()))
		{
			this->gameOver = true;
			this->gameQuit();
		}
	}
	if (X < 20.f || Y < 20.f || X > 590 || Y > 590)
	{
		this->gameOver = true;
		this->gameQuit();
	}
}

void Snake::fruitSpawn()
{
	this->posX = static_cast<float>(rand() % static_cast<int>((this->window->getSize().x - 20) - this->fruit.getSize().x));
	this->posY = static_cast<float>(rand() % static_cast<int>((this->window->getSize().y - 20) - this->fruit.getSize().y));
	if (this->posX < 20.f)
		this->posX += 30.f;
	if (this->posY < 20.f)
		this->posY += 30.f;
	while (static_cast<int>(this->posX) % 20 != 0 || static_cast<int>(this->posY) % 20 != 0)
	{
		if (static_cast<int>(this->posX) % 20 != 0)
			this->posX += 1.f;
		if (static_cast<int>(this->posY) % 20 != 0)
			this->posY += 1.f;
	}
	fruit.setPosition(sf::Vector2f(this->posX, this->posY));
	int color1 = rand() % 3;
	switch (color1)
	{
	case 0:
		this->fruit.setFillColor(sf::Color::Red);
		break;
	case 1:
		this->fruit.setFillColor(sf::Color(255,52,0));
		break;
	case 2:
		this->fruit.setFillColor(sf::Color::Yellow);
		break;
	}
}

sf::RectangleShape Snake::makeTail()
{
	sf::RectangleShape box;
	box.setFillColor(sf::Color(this->colorTail3,this->colorTail2,this->colorTail,255));
	box.setSize(sf::Vector2f(20.f, 20.f));
	box.setPosition(sf::Vector2f(X, Y));
	return box;
}

void Snake::gameQuit()
{
	std::stringstream ss;
	ss << "Game Over\n   Score: " << score;
	text.setCharacterSize(45);
	text.setPosition(sf::Vector2f(215.f,215.f));
	text.setFillColor(sf::Color::Red);
}

void Snake::logic()
{
	if (this->head.getGlobalBounds().intersects(this->fruit.getGlobalBounds()))
	{
		this->tail.push_back(this->makeTail());
		this->score++;
		this->tailLen++;
		this->fruitSpawn();
	}
	if (tailLen != 0)
	{
		float prevX = tail[0].getPosition().x;
		float prevY = tail[0].getPosition().y;
		tail[0].setPosition(sf::Vector2f(this->X, this->Y));
		float prev2X, prev2Y;
		for (int i = 1; i < tailLen; i++)
		{
			prev2X = tail[i].getPosition().x;
			prev2Y = tail[i].getPosition().y;
			tail[i].setPosition(sf::Vector2f(prevX, prevY));
			prevX = prev2X;
			prevY = prev2Y;
		}
	}
}

void Snake::input()
{
	if (sf::Keyboard::isKeyPressed(sf::Keyboard::A) && dir != RIGHT)
		this->dir = LEFT;
	else if (sf::Keyboard::isKeyPressed(sf::Keyboard::D) && dir != LEFT)
		this->dir = RIGHT;
	else if (sf::Keyboard::isKeyPressed(sf::Keyboard::S) && dir != UP)
		this->dir = DOWN;
	else if (sf::Keyboard::isKeyPressed(sf::Keyboard::W) && dir != DOWN)
		this->dir = UP;
}

void Snake::run()
{
	while (this->window->isOpen())
	{
		this->update();
		this->render();
	}
}

void Snake::update()
{
	this->pollEvent();
	if (!gameOver)
	{
		this->input();
		this->logic();
		this->setDirection();
		this->collision();
		this->updateText();
	}
}

void Snake::render()
{
	this->window->clear(sf::Color(0,0,0,0));
	if (!gameOver)
	{
		this->window->draw(this->background1);
		this->window->draw(this->fruit);
		this->window->draw(this->head);
		for (auto& e : tail)
		{
			this->window->draw(e);
		}
	}
	this->window->draw(this->text);
	this->window->display();
}
//Cons && Des
Snake::Snake()
{
	this->initVar();
	this->initWindow();
	this->initRect();
	this->initFont();
	this->initText();
}

Snake::~Snake()
{
	delete this->window;
}
