#include "Snake.h"

int main()
{
	Snake snake;	
	snake.run();
}