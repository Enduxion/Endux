#pragma once
#include"Button.h"

class MainClass
{
private:
	// SFML Variables
	sf::RenderWindow* window;
	sf::VideoMode videoMode;
	sf::Event ev;
	sf::RectangleShape sb;

	Button *PsQuit, *PsResume;
	Button *GameOverQuit, *GameOverRestart;
	Button *MainMenuStart, *MainMenuQuit;

	sf::RectangleShape MouseBox;

	sf::RectangleShape guiBoostCount, guiBoostBg;
	sf::RectangleShape guiHp, guiHpBg;

	sf::Font font;
	sf::Text gameOverText, scoreText, pauseText;

	sf::SoundBuffer hitBox, eatFood;
	sf::Sound hitBoxSound, eatFoodSound;
	
	sf::Image icon;

	float hp, hpmax;
	int score;
	bool restart;
	bool startGame;
	float velocityX, velocityY, prevX, prevY, rotationRate;
	unsigned redC, greenC, blueC;
	bool canBoost;
	bool bGameOver;
	float counterForBoost, counterOnly;
	int maxDots, numberOfDots;
	sf::View view;

	bool inPauseState;

	std::vector<sf::RectangleShape> randomDots;
	bool redReachedMax, blueReachedMax, greenReachedMax;
	// Initializaer Functions
	void initVar();
	void initRestartVar();
	void initWindow();
	void initShapes();

public:
	// public functions
	void run();
	void movement();

	void gameOver();
	void pauseState();
	void updateHpGui();
	void update();
	void render();
	void pollEvent();
	void spawnDots();
	void mainMenu();
	// Constructors and Destructors
	MainClass();
	virtual ~MainClass();

};

