#include "MainClass.h"
// Initializer Functions
void MainClass::initVar()
{
	this->window = nullptr;
	this->initRestartVar();
}
void MainClass::initRestartVar()
{
	this->velocityX = 0;
	this->velocityY = 0;
	this->counterForBoost = 480;
	this->counterOnly = 0;
	canBoost = true;
	this->bGameOver = false;
	this->inPauseState = false;
	this->restart = false;
	this->startGame = false;
	this->redC = 255;
	this->blueC = 0;
	this->greenC = 100;

	this->maxDots = 40;
	this->numberOfDots = 0;

	this->hpmax = 480;
	this->hp = 480;

	this->score = 0;

	this->font.loadFromFile("./Font/font.ttf");
	this->scoreText.setCharacterSize(14);
	this->scoreText.setFont(font);
	this->scoreText.setFillColor(sf::Color::White);
	this->scoreText.setPosition(sf::Vector2f(8.f, 52.f));

	this->hitBox.loadFromFile("./Audio/hitBox.wav");
	this->hitBoxSound.setBuffer(hitBox);

	this->eatFood.loadFromFile("./Audio/eatFood.wav");
	this->eatFoodSound.setBuffer(this->eatFood);

	if (this->randomDots.size() != 0) {
		randomDots.clear();
	}
}
void MainClass::initWindow()
{
	this->icon.loadFromFile("./Image/Icon.png");
	this->videoMode.width = 800;
	this->videoMode.height = 600;
	this->window = new sf::RenderWindow(this->videoMode, "SGT", sf::Style::Fullscreen);
	this->window->setFramerateLimit(120);
	this->window->setIcon(this->icon.getSize().x, this->icon.getSize().y, this->icon.getPixelsPtr());
}

void MainClass::initShapes()
{
	MouseBox.setSize(sf::Vector2f(1, 1));

	sb.setSize(sf::Vector2f(15.f, 15.f));
	sb.setPosition(sf::Vector2f((this->window->getSize().x / 2) - (this->sb.getSize().x / 2), (this->window->getSize().y / 2) - (this->sb.getSize().y / 2)));
	sb.setFillColor(sf::Color::White);
	sb.setOrigin(sf::Vector2f(
		sb.getSize().x / 2,
		sb.getSize().y / 2
	));


	guiBoostCount.setPosition(sf::Vector2f(10.f, 10.f));
	guiBoostCount.setSize(sf::Vector2f(48.f, 10.f));
	guiBoostCount.setFillColor(sf::Color::White);

	guiBoostBg.setPosition(sf::Vector2f(8.f, 8.f));
	guiBoostBg.setSize(sf::Vector2f(52.f, 14.f));
	guiBoostBg.setFillColor(sf::Color(120, 120, 120, 120));

	guiHp.setPosition(sf::Vector2f(10.f, 30.f));
	guiHp.setFillColor(sf::Color::Green);
	guiHp.setSize(sf::Vector2f(48.f, 10.f));

	guiHpBg.setPosition(sf::Vector2f(8.f, 28.f));
	guiHpBg.setSize(sf::Vector2f(52.f, 14.f));
	guiHpBg.setFillColor(sf::Color(120, 120, 120, 120));

	// Init Buttons

	sf::Vector2f pos2 = sf::Vector2f(
		static_cast<float>((this->window->getSize().x / 2) - 58.f),
		static_cast<float>((this->window->getSize().y / 2) - 28.f)
	);

	sf::Vector2f pos = sf::Vector2f(pos2.x + 25.f, pos2.y - 2.f);

	sf::Vector2f sizeOfBox = sf::Vector2f(150, 41);

	PsResume = new Button("Resume", 33, pos, "./Font/font.ttf", pos2, sizeOfBox);
	// 
	//
	sf::Vector2f pos3 = sf::Vector2f(
		static_cast<float>((this->window->getSize().x / 2) - 58.f),
		static_cast<float>((this->window->getSize().y / 2) + 28.f)
	);

	sf::Vector2f pos4 = sf::Vector2f(pos3.x + 50.f, pos3.y - 2.f);

	sf::Vector2f sizeOfBox1 = sf::Vector2f(150, 41);

	PsQuit = new Button("Quit", 33, pos4, "./Font/font.ttf", pos3, sizeOfBox1);

	this->view.setCenter(this->sb.getPosition());
	this->view.setSize(sf::Vector2f(this->window->getSize().x, this->window->getSize().y));
}

// Public Functions
void MainClass::run()
{
	while (this->window->isOpen())
	{
		this->update();
		this->render();
	}
}

void MainClass::update()
{
	this->pollEvent();
	this->movement();
	this->spawnDots();
	this->updateHpGui();
}

void MainClass::mainMenu()
{
	sf::Texture palpa;
	palpa.loadFromFile("./Image/MainMenuBackGround.png");
	sf::RectangleShape bg;
	bg.setTexture(&palpa);
	bg.setSize(sf::Vector2f(static_cast<float>(this->window->getSize().x), static_cast<float>(this->window->getSize().y)));
	sf::Vector2f startPosition = sf::Vector2f(45.f, static_cast<float>(this->window->getSize().y / 2) + 53.f);
	sf::Vector2f quitPosition = sf::Vector2f(45.f, static_cast<float>(this->window->getSize().y / 2) + 122.f);

	sf::Vector2f startPositionBox = sf::Vector2f(20.f, static_cast<float>(this->window->getSize().y / 2) + 55.f);
	sf::Vector2f quitPositionBox = sf::Vector2f(20.f, static_cast<float>(this->window->getSize().y / 2) + 125.f);

	sf::Vector2f sizeOfBoxes = sf::Vector2f(200, 55);

	this->MainMenuStart = new Button("Start", 44, startPosition, "./Font/font.ttf", startPositionBox, sizeOfBoxes);
	this->MainMenuQuit = new Button("Quit", 44, quitPosition, "./Font/font.ttf", quitPositionBox, sizeOfBoxes);

	while (!startGame) {
		this->pollEvent();
		//
		if (this->MainMenuQuit->getBounds().intersects(this->MouseBox.getGlobalBounds()))
		{
			if (sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
				exit(0);
			}
			this->MainMenuQuit->boldText();
		}
		else
		{
			this->MainMenuQuit->unboldText();
		}
		// 
		if (this->MainMenuStart->getBounds().intersects(this->MouseBox.getGlobalBounds()))
		{
			if (sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
				startGame = true;
			}
			this->MainMenuStart->boldText();
		}
		else
		{
			this->MainMenuStart->unboldText();
		}
		this->window->clear();
		this->window->draw(bg);
		this->MainMenuQuit->render(*this->window);
		this->MainMenuStart->render(*this->window);
		this->window->display();
	}
}

void MainClass::updateHpGui()
{
	int highscore;
	std::ifstream getHs("./HighScore/HighScore.dat");
	getHs >> highscore;
	getHs.close();
	this->hp -= 0.3f;
	this->guiHp.setSize(sf::Vector2f(hp / 10.f, this->guiHp.getSize().y));

	if (hp <= 0) {
		this->gameOver();
	}
	std::stringstream ss;
	ss << "Score: " << score << "\n" << "Highscore: " << highscore;
	this->scoreText.setString(ss.str());
}

void MainClass::gameOver()
{
	sf::Texture palpa;
	palpa.loadFromFile("./Image/GameOverBackGround.png");
	sf::RectangleShape bg;
	bg.setTexture(&palpa);
	bg.setSize(sf::Vector2f(static_cast<float>(this->window->getSize().x), static_cast<float>(this->window->getSize().y)));
	// Buttons

	sf::Vector2f pos2 = sf::Vector2f(
		static_cast<float>((this->window->getSize().x / 2) - 58.f),
		static_cast<float>((this->window->getSize().y / 2) - 28.f)
	);

	sf::Vector2f pos = sf::Vector2f(pos2.x + 25.f, pos2.y - 2.f);

	sf::Vector2f sizeOfBox = sf::Vector2f(150, 41);

	GameOverRestart = new Button("Restart", 36, pos, "./Font/font.ttf", pos2, sizeOfBox);
	//
	//
	sf::Vector2f pos3 = sf::Vector2f(
		static_cast<float>((this->window->getSize().x / 2) - 58.f),
		static_cast<float>((this->window->getSize().y / 2) + 28.f)
	);

	sf::Vector2f pos4 = sf::Vector2f(pos3.x + 50.f, pos3.y - 2.f);

	sf::Vector2f sizeOfBox1 = sf::Vector2f(150, 41);

	GameOverQuit = new Button("Quit", 36, pos4, "./Font/font.ttf", pos3, sizeOfBox1);


	this->bGameOver = true;
	this->gameOverText.setCharacterSize(34);
	this->gameOverText.setFont(font);
	this->gameOverText.setFillColor(sf::Color::White);
	this->gameOverText.setPosition(sf::Vector2f(
		static_cast<float>(this->window->getSize().x / 2 - 58),
		30.f
	));
	std::stringstream ss;
	ss << "Game Over\nScore: " << score;
	this->gameOverText.setString(ss.str());
	// Saving HighScore

	int hshs = 0;
	std::ifstream getHs("./HighScore/HighScore.dat");
	getHs >> hshs;
	getHs.close();
	if (hshs < score) {
		std::ofstream setHs("./HighScore/HighScore.dat");
		setHs << score;
		setHs.close();
	}
	restart = false;
	while (!restart) {
		//
		this->pollEvent();
		if (this->GameOverQuit->getBounds().intersects(MouseBox.getGlobalBounds())) {
			GameOverQuit->boldText();
			if (sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
				exit(0);
			}
		}
		else {
			GameOverQuit->unboldText();
		}

		if (this->GameOverRestart->getBounds().intersects(MouseBox.getGlobalBounds())) {
			GameOverRestart->boldText();
			if (sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
				restart = true;
			}
		}
		else {
			GameOverRestart->unboldText();
		}	

		//
		this->window->clear();
		this->window->draw(bg);
		this->window->draw(gameOverText);
		this->GameOverQuit->render(*this->window);
		this->GameOverRestart->render(*this->window);
		this->window->display();
	}
	if (restart) {
		this->initRestartVar();
		this->initShapes();
		this->run();
	}
}

void MainClass::spawnDots()
{
	if (numberOfDots < maxDots && counterOnly == 30) {
		sf::RectangleShape s;
		s.setFillColor(sf::Color::White);
		s.setSize(sf::Vector2f(static_cast<float>(rand() % 5), static_cast<float>(rand() % 5)));
		s.setPosition(sf::Vector2f(static_cast<float>(rand() % this->window->getSize().x), static_cast<float>(rand() % this->window->getSize().y)));
		this->randomDots.push_back(s);
		numberOfDots++;
	}
	counterOnly++;

	if (counterOnly > 30)
		counterOnly = 0;
}

void MainClass::movement()
{
	if (counterForBoost >= 480) {
		canBoost = true;
	}
	else {
		guiBoostCount.setSize(sf::Vector2f(this->guiBoostCount.getSize().x + 0.1f,this->guiBoostCount.getSize().y));
		counterForBoost++;
	}

	if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::A) && velocityX > -30) {
		if (rotationRate > -8.f)
			rotationRate -= 1.f;
		velocityX -= 0.1f;
	}
	else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::D ) && velocityX < 30) {
		if (rotationRate < 8.f)
			rotationRate += 1.f;
		velocityX += 0.1f;
	}
	if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::W) && velocityY > -30) {
		if (rotationRate > -8.f)
			rotationRate -= 1.f;
		velocityY -= 0.1f;
	}
	else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::S) && velocityY < 30) {
		if (rotationRate < 8.f)
			rotationRate += 1.f;
		velocityY += 0.1f;
	}

	if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::Space) && velocityX < 200 && velocityY < 200 && velocityX > -200 && velocityY > -200 && canBoost) {
		if (velocityX != 0) {
			velocityX *= 4.f;
		}
		if (velocityY != 0.f) {
			velocityY *= 4.f;
		}
		canBoost = false;
		counterForBoost = 0;
		guiBoostCount.setSize(sf::Vector2f(0.f, this->guiBoostCount.getSize().y));
	}

	this->sb.move(velocityX, velocityY);
	if (velocityX > 0) {
		velocityX -= 0.01f;
	}
	else if (velocityX < 0) {
		velocityX += 0.01f;
	}
	if (velocityY > 0) {
		velocityY -= 0.01f;
	}
	else if (velocityY < 0) {
		velocityY += 0.01f;
	}

	if (rotationRate > 0)
		rotationRate -= 0.1f;
	else if (rotationRate < 0)
		rotationRate += 0.1f;

	if (this->sb.getPosition().x <= 0) {
		this->sb.setPosition(sf::Vector2f(0, this->sb.getPosition().y));
		this->velocityX *= -0.9f;
		if (this->hitBoxSound.getStatus() != this->hitBoxSound.Playing)
			this->hitBoxSound.play();
		if (rotationRate < 8.f)
			rotationRate += 2.f;
	}
	else if (this->sb.getPosition().x >= static_cast<float>(this->window->getSize().x) - this->sb.getSize().x) {
		this->sb.setPosition(sf::Vector2f(static_cast<float>(this->window->getSize().x) - this->sb.getSize().x, this->sb.getPosition().y));
		this->velocityX *= -0.9f;
		if (this->hitBoxSound.getStatus() != this->hitBoxSound.Playing)
			this->hitBoxSound.play();
		if (rotationRate > -8.f)
			rotationRate -= 2.f;
	}
	if (this->sb.getPosition().y <= 0) {
		this->sb.setPosition(sf::Vector2f(this->sb.getPosition().x, 0));
		this->velocityY *= -0.9f;
		if (this->hitBoxSound.getStatus() != this->hitBoxSound.Playing)
			this->hitBoxSound.play();
		if (rotationRate < 8.f)
			rotationRate += 2.f;
	}
	else if (this->sb.getPosition().y >= static_cast<float>(this->window->getSize().y) - this->sb.getSize().y) {
		this->sb.setPosition(sf::Vector2f(this->sb.getPosition().x, static_cast<float>(this->window->getSize().y) - this->sb.getSize().y));
		this->velocityY *= -0.9f;
		if (this->hitBoxSound.getStatus() != this->hitBoxSound.Playing)
			this->hitBoxSound.play();
		if (rotationRate > -8.f)
			rotationRate -= 2.f;
	}
	this->sb.setRotation(sb.getRotation() + rotationRate);
	if (redC >= 255)
		redReachedMax = true;
	if (blueC >= 255)
		blueReachedMax = true;
	if (greenC >= 255)
		greenReachedMax = true;

	if (redReachedMax) {
		redC--;
		if (redC <= 0)
			redReachedMax = false;
	}
	else {
		redC++;
	}

	if (blueReachedMax) {
		blueC--;
		if (blueC <= 0)
			blueReachedMax = false;
	}
	else {
		blueC++;
	}

	if (greenReachedMax) {
		greenC--;
		if (greenC <= 0)
			greenReachedMax = false;
	}
	else {
		greenC++;
	}

	if (counterForBoost >= 30) {
		this->sb.setFillColor(sf::Color(redC, greenC, blueC, 255));
	}

	for (int i = 0; i < this->randomDots.size(); i++) {
		if (this->sb.getGlobalBounds().intersects(randomDots[i].getGlobalBounds())) {
			this->randomDots.erase(this->randomDots.begin() + i, this->randomDots.begin() + i + 1);
			if (this->eatFoodSound.getStatus() != this->eatFoodSound.Playing) {
				this->eatFoodSound.play();
			}
			score++;
			numberOfDots--;
			i--;
			if (hp <= 432)
				hp += 48;
		}
	}
}

void MainClass::pauseState()
{
	sf::RectangleShape pauseStateBlank;
	pauseStateBlank.setFillColor(sf::Color(0, 0, 0, 130));
	pauseStateBlank.setSize(sf::Vector2f(static_cast<float>(this->window->getSize().x), static_cast<float>(this->window->getSize().y)));

	this->pauseText.setFont(font);
	this->pauseText.setCharacterSize(44);
	this->pauseText.setString("Paused");
	this->pauseText.setPosition(sf::Vector2f(
		static_cast<float>(this->window->getSize().x / 2 - 58),
		45
	));

	while (inPauseState) {
		this->pollEvent();

		if (this->PsQuit->getBounds().intersects(MouseBox.getGlobalBounds())) {
			PsQuit->boldText();
			if (sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
				exit(0);
			}
		}
		else {
			PsQuit->unboldText();
		}

		if (this->PsResume->getBounds().intersects(MouseBox.getGlobalBounds())) {
			PsResume->boldText();
			if (sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
				inPauseState = false;
			}
		}
		else {
			PsResume->unboldText();
		}

		// Render
		this->window->clear();
		for (auto& e : this->randomDots) {
			this->window->draw(e);
		}
		this->window->draw(this->sb);
		this->window->draw(this->guiBoostBg);
		this->window->draw(this->guiBoostCount);
		this->window->draw(this->guiHpBg);
		this->window->draw(this->guiHp);
		this->window->draw(scoreText);
		this->window->draw(pauseStateBlank);
		this->window->draw(pauseText);
		PsResume->render(*this->window);
		PsQuit->render(*this->window);
		this->window->display();
	}
}

void MainClass::render()
{
	this->window->clear();
	this->window->setView(this->view);
	for (auto& e : this->randomDots) {
		this->window->draw(e);
	}
	this->window->draw(this->sb);
	this->window->draw(this->guiBoostBg);
	this->window->draw(this->guiBoostCount);
	this->window->draw(this->guiHpBg);
	this->window->draw(this->guiHp);
	this->window->draw(scoreText);
	this->window->display();
}

void MainClass::pollEvent()
{
	while (this->window->pollEvent(this->ev))
	{
		switch (this->ev.type)
		{
		case sf::Event::Closed:
			this->window->close();
			break;
		case sf::Event::KeyPressed:
			if (this->ev.key.code == sf::Keyboard::Escape && !inPauseState && !bGameOver) {
				inPauseState = true;
				this->pauseState();
			}
			else if (this->ev.key.code == sf::Keyboard::Escape && inPauseState && !bGameOver) {
				inPauseState = false;
			}
		}
	}
	// Mouse

	MouseBox.setPosition(sf::Vector2f(
		static_cast<float>(sf::Mouse::getPosition(*this->window).x),
		static_cast<float>(sf::Mouse::getPosition(*this->window).y)
	));
}
// Constructor and Destructors
MainClass::MainClass()
{
	this->initVar();
	this->initWindow();
	this->initShapes();
	this->mainMenu();
}
MainClass::~MainClass()
{
	delete this->PsQuit;
	delete this->PsResume;
	delete this->GameOverQuit;
	delete this->GameOverRestart;
	delete this->window;
}