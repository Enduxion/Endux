#include"MainClass.h"
int main()
{
	srand(static_cast<unsigned>(time(NULL)));
	MainClass game;
	game.run();
	return 0;
}