#include"RMain.h"
// Straight line at 1150
// Private Functions
void RMain::initVar() {
	this->window = nullptr;
	this->isAddPressed = false;
	this->isAnglePressed = false;
	this->isVelocityPressed = false;
	this->isAngleTextPressed = false;
	this->isVelocityTextPressed = false;
}
void RMain::initWindow() {
	this->window = new sf::RenderWindow(sf::VideoMode(), "Projectile Motion", sf::Style::Fullscreen);
	this->window->setFramerateLimit(120);
}
void RMain::initVarWin() {
	float x = (float)this->window->getSize().x - 100.f;
	float y = 50.f;
	this->uBody.setFillColor(sf::Color::Red);
	this->uBody.setPosition(sf::Vector2f(0, float(this->window->getSize().y) - 10.f));
	this->uBody.setSize(sf::Vector2f(5.f, 10.f));
	this->button = new Button("Add", 34, sf::Vector2f(x - 100.f, y + 100.f), "./Font/font.ttf", sf::Vector2f(x - 107.f, y + 103.f), sf::Vector2f(75.f, 38.f));
	this->button1 = new Button("Clear", 34, sf::Vector2f(x - 100.f, y + 150.f), "./Font/font.ttf", sf::Vector2f(x - 107.f, y + 153.f), sf::Vector2f(75.f, 38.f));
	//.........//
	this->angleTextBox = new TextBox(false, 34, sf::Vector2f(x - 105.f, y), sf::Color::Black, sf::Vector2f(170.f, 38.f), sf::Color(23, 23, 23, 123), sf::Vector2f(x - 107.f, y + 3.f), 5, "./Font/font.ttf", "Angle", sf::Color(234, 234, 234, 134));
	this->velocityTextBox = new TextBox(false, 34, sf::Vector2f(x - 105.f, y + 50.f), sf::Color::Black, sf::Vector2f(170.f, 38.f), sf::Color(23, 23, 23, 123), sf::Vector2f(x - 107.f, y + 53.f), 5, "./Font/font.ttf", "Velocity", sf::Color(234, 234, 234, 134));
	//........//
	this->theLine.setPosition(sf::Vector2f(1150.f, 0.f));
	this->theLine.setSize(sf::Vector2f(2.f, (float)this->window->getSize().y));
	this->theLine.setFillColor(sf::Color::Black);
	
}
// Public Functions
float RMain::strToFloat(std::string str) {
	float finalValue = 0.f;
	int dot = 0;
	bool isDotFound = false;
	// For getting the position of the dot
	for (int i = 0; i < str.length(); i++) {
		if (str[i] == '.') {
			isDotFound = true;
			dot = i;
			break;
		}
	}
	if (!isDotFound) {
		for (int i = 0; i < str.length(); i++) {
			finalValue += float((str[i] - 48) * pow(10, str.length() -i - 1));
		}
	}
	else {
		for (int i = 0; i < str.length(); i++) {
			char Ichar = str[i];
			if (dot == 0 && str.length() == 1) { break; }
			if (i < dot) {
				finalValue += float((Ichar - 48) * pow(10, (dot - i) - 1));
			}
			else if (i > dot) {
				finalValue += (float(Ichar - 48) / float(pow(10, (i - dot))));
			}
		}
	}
	return finalValue;
}
bool RMain::isMouseAdd() {
	sf::Vector2f mouseFloatPosition = sf::Vector2f(float(this->mouse.getPosition().x), float(this->mouse.getPosition().y));
	if (this->button->getBounds().contains(mouseFloatPosition)) {
		return true;
	}
	return false;
}
bool RMain::isMouseClear() {
	sf::Vector2f mouseFloatPosition = sf::Vector2f(float(this->mouse.getPosition().x), float(this->mouse.getPosition().y));
	if (this->button1->getBounds().contains(mouseFloatPosition)) {
		return true;
	}
	return false;
}
bool RMain::isMouseAngle() {
	sf::Vector2f mouseFloatPosition = sf::Vector2f(float(this->mouse.getPosition().x), float(this->mouse.getPosition().y));
	if (this->angleTextBox->getBounds().contains(mouseFloatPosition)) {
		return true;
	}
	return false;
}
bool RMain::isMouseVelocity() {
	sf::Vector2f mouseFloatPosition = sf::Vector2f(float(this->mouse.getPosition().x), float(this->mouse.getPosition().y));
	if (this->velocityTextBox->getBounds().contains(mouseFloatPosition)) {
		return true;
	}
	return false;
}
void RMain::addProjectile() {
	float initialVelocity = (this->strToFloat(this->velocityTextBox->getValue()));
	float angle = this->strToFloat(this->angleTextBox->getValue());
	this->angleTextBox->resetText();
	this->velocityTextBox->resetText();
	Projectile* projectile = new Projectile(angle, initialVelocity, sf::Vector2f(5.f, float(this->window->getSize().y) - 10.f), this->window->getSize().y);
	this->projectiles.push_back(projectile);
}
void RMain::clearProjectile() {
	for (auto& e : this->projectiles) {
		delete e;
	}
	this->projectiles.clear();
}
void RMain::updateProjectiles() {
	for (auto& e : this->projectiles) {
		if (!e->getFinished()) {
			e->update(e->getPrevT(), this->window->getSize().y);
		}
	}
}
void RMain::run() {
	while (this->window->isOpen()) {
		this->update();
		this->render();
	}
}
void RMain::pollEvents() {
	while (this->window->pollEvent(this->ev)) {
		switch (this->ev.type) {
		case sf::Event::Closed:
			this->window->close();
			break;
		}
	}
}
void RMain::update() {
	this->updateProjectiles();
	// Check if mouse on button
	if (this->isMouseAdd()) {
		this->button->boldText();
		if (sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
			if (!this->isAddPressed) {

				if (this->angleTextBox->getValue().length() == 0) {
					this->angleTextBox->setPlaceHolderColor(sf::Color::Red);
				}
				if (this->velocityTextBox->getValue().length() == 0) {
					this->velocityTextBox->setPlaceHolderColor(sf::Color::Red);
				}
				if (this->velocityTextBox->getValue().length() != 0 && this->angleTextBox->getValue().length() != 0) {
					this->angleTextBox->setPlaceHolderColor(sf::Color(234, 234, 234, 134));
					this->velocityTextBox->setPlaceHolderColor(sf::Color(234, 234, 234, 134));
					this->addProjectile();
				}

				this->isAddPressed = true;
				this->velocityTextBox->setSelected(false);
				this->angleTextBox->setSelected(false);
			}
		}
		else {
			this->isAddPressed = false;
		}
	}
	else {
		this->button->unboldText();
	}
	// If mouse on Angle Specifier
	if (this->isMouseAngle()) {
		if (sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
			if (!this->isAnglePressed) {
				this->velocityTextBox->setSelected(false);
				this->angleTextBox->setSelected(true);
				this->isAnglePressed = true;
			}
		}
		else {
			this->isAnglePressed = false;
		}
	}
	// If mouse on Velocity Specifier
	if (this->isMouseVelocity()) {
		if (sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
			if (!this->isVelocityPressed) {
				this->angleTextBox->setSelected(false);
				this->velocityTextBox->setSelected(true);
				this->isVelocityPressed = true;
			}
		}
		else {
			this->isVelocityPressed = false;
		}
	}
	if (this->isMouseClear()) {
		this->button1->boldText();
		if (sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
			if (!this->isClearPressed) {
				this->clearProjectile();
				this->isClearPressed = true;
				this->velocityTextBox->setSelected(false);
				this->angleTextBox->setSelected(false);
			}
		}
		else {
			this->isClearPressed = false;
		}
	}
	else {
		this->button1->unboldText();
	}
	if (sf::Mouse::isButtonPressed(sf::Mouse::Left) && !this->isMouseAdd() && !this->isMouseAngle() && !this->isMouseVelocity()) {
		this->velocityTextBox->setSelected(false);
		this->angleTextBox->setSelected(false);
	}

	if (this->angleTextBox->isBoxSelected()) this->angleTextBox->highLightBox(true);
	else this->angleTextBox->highLightBox(false);
	if (this->velocityTextBox->isBoxSelected()) this->velocityTextBox->highLightBox(true);
	else this->velocityTextBox->highLightBox(false);

	this->textInput();
	this->pollEvents();
}
void RMain::textInput() {
	if (this->angleTextBox->isBoxSelected()) {
		if (this->ev.type == sf::Event::TextEntered) {
			if (!this->isAngleTextPressed) {
				if ((this->ev.text.unicode >= '0' && this->ev.text.unicode <= '9') || this->ev.text.unicode == '.' || this->ev.text.unicode == DELETE_KEY || this->ev.text.unicode == ENTER_KEY || this->ev.text.unicode == ESCAPE_KEY) {
					if ((this->ev.text.unicode == '.' && !this->angleTextBox->hasChar('.')) || this->ev.text.unicode != '.')
						this->angleTextBox->takeInput(this->ev);
				}
				this->isAngleTextPressed = true;
			}
		}
		else {
			this->isAngleTextPressed = false;
		}
	}
	if (this->velocityTextBox->isBoxSelected()) {
		if (this->ev.type == sf::Event::TextEntered) {
			if (!this->isVelocityTextPressed) {
				if ((this->ev.text.unicode >= '0' && this->ev.text.unicode <= '9') || this->ev.text.unicode == '.' || this->ev.text.unicode == DELETE_KEY || this->ev.text.unicode == ENTER_KEY || this->ev.text.unicode == ESCAPE_KEY) {
					if ((this->ev.text.unicode == '.' && !this->velocityTextBox->hasChar('.')) || this->ev.text.unicode != '.')
						this->velocityTextBox->takeInput(this->ev);
				}
				this->isVelocityTextPressed = true;
			}
		}
		else {
			this->isVelocityTextPressed = false;
		}
	}
}
void RMain::render() {
	this->window->clear(sf::Color::White);
	this->angleTextBox->render(*this->window);
	this->velocityTextBox->render(*this->window);
	this->button->render(*this->window);
	this->button1->render(*this->window);
	this->window->draw(this->theLine);
	for (auto& e : this->projectiles) {
		e->render(*this->window);
	}
	this->window->draw(this->uBody);
	this->window->display();
}
// Constructors and Destructors
RMain::RMain() {
	this->initVar();
	this->initWindow();
	this->initVarWin();
}
RMain::~RMain() {
	for (auto &e : this->projectiles) {
		delete e;
	}
	delete this->button;
	delete this->angleTextBox;
	delete this->velocityTextBox;
	delete this->window;
}