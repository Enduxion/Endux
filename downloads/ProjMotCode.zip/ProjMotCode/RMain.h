#pragma once
#include"Projectile.h"
class RMain
{
private:
	// Variables
	sf::RenderWindow* window;
	sf::Event ev;
	sf::RectangleShape uBody;
	sf::Mouse mouse;
	sf::RectangleShape theLine;

	std::vector<Projectile*> projectiles;
	Button* button;
	Button* button1;
	TextBox* angleTextBox;
	TextBox* velocityTextBox;

	bool isAddPressed, isAnglePressed, isVelocityPressed, isClearPressed; 

	bool isAngleTextPressed, isVelocityTextPressed;
	// Private Functions
	float strToFloat(std::string str);
	void initVar();
	void initWindow();
	void initVarWin();
	void addProjectile();
	void clearProjectile();
	void textInput();
	bool isMouseAdd();
	bool isMouseClear();
	bool isMouseAngle();
	bool isMouseVelocity();
	void updateProjectiles();
public:
	// Public Functions
	void run();
	void pollEvents();
	void update();
	void render();
	// Constructors and Destructors
	RMain();
	virtual ~RMain();
};

