#include"RMain.h"
int main() {
	RMain rmain;
	rmain.run();
	return 0;
}