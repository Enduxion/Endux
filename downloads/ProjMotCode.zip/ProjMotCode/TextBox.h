#pragma once
#include"Button.h"
#define DELETE_KEY 8
#define ENTER_KEY 13
#define ESCAPE_KEY 27

class TextBox
{
private:
	sf::Font font;
	sf::Text text;
	sf::RectangleShape box;
	std::ostringstream textContained;

	sf::Color realTextColor;
	sf::Color phColor;
	std::string placeholder;

	bool isSel;
	unsigned limit = 1000;
public:
	// Getters and setters
	bool isBoxSelected() { return this->isSel; }
	void setSelected(bool isSel) { this->isSel = isSel; }
	void setPlaceHolderColor(sf::Color color) { this->phColor = color; }
	void setLimit(unsigned limit) { this->limit = limit; }
	const sf::FloatRect& getBounds() const { return this->box.getGlobalBounds(); }
	std::string getValue() { return this->textContained.str(); }

	void resetText() {
		this->textContained.str("");
	}
	// Extras
	void deleteLogic() {
		std::string rText;
		for (int i = 0; i < textContained.str().length() - 1; i++) {
			rText += textContained.str()[i];
		}
		textContained.str("");
		textContained << rText;
	}

	bool hasChar(char character) {
		for (int i = 0; i < textContained.str().length(); i++) {
			if (textContained.str()[i] == character) return true;
		}
		return false;
	}

	void takeInput(sf::Event& charEvent) {
		char character = charEvent.text.unicode;
		if ((character != DELETE_KEY && character != ENTER_KEY && character != ESCAPE_KEY) && this->textContained.str().length() < this->limit) {
			textContained << character;
		}
		else if (character == DELETE_KEY && this->textContained.str().length() > 0) {
			this->deleteLogic();
		}
		else if (character == ESCAPE_KEY || character == ENTER_KEY) {
			this->isSel = false;
		}
		this->text.setString(this->textContained.str());
	}


	void highLightBox(bool ToF) {
		if (ToF) this->box.setOutlineThickness(2);
		else this->box.setOutlineThickness(1);
	}


	void render(sf::RenderTarget& target) {
		if (isSel == true) {
			this->text.setFillColor(this->realTextColor);
			this->text.setString(this->textContained.str() + "_");
		}
		else if (isSel == false && this->textContained.str().length() == 0) {
			this->text.setFillColor(this->phColor);
			this->text.setString(this->placeholder);
		}
		else {
			this->text.setFillColor(this->realTextColor);
			this->text.setString(this->textContained.str());
		}
		target.draw(this->box);
		target.draw(this->text);
	}


	// Constructor
	TextBox(bool isSel, int textSize, sf::Vector2f positionOfText, sf::Color textColor, sf::Vector2f sizeOfBox, sf::Color boxColor, sf::Vector2f positionOfBox, unsigned limit, std::string fontText, std::string placeholder, sf::Color placeholderColor) {
		this->isSel = isSel;
		this->text.setCharacterSize(textSize);
		this->text.setPosition(positionOfText);
		this->text.setFillColor(placeholderColor);
		this->box.setSize(sizeOfBox);
		this->box.setFillColor(boxColor);
		this->box.setPosition(positionOfBox);
		this->box.setOutlineThickness(1);
		this->box.setOutlineColor(textColor);
		this->limit = limit;
		this->font.loadFromFile(fontText);
		this->text.setFont(this->font);
		this->text.setString(placeholder);

		this->realTextColor = textColor;
		this->phColor = placeholderColor;
		this->placeholder = placeholder;
	}
};

