#pragma once
#include"SFML\Graphics.hpp"
#include"SFML\Window.hpp"
#include"SFML\Audio.hpp"
#include"SFML\Network.hpp"
#include"SFML\System.hpp"
#include<iostream>
#include<ctime>
#include<cstdlib>
#include<vector>
#include<sstream>
#include<fstream>
#include<string>
class Button
{
private:
	sf::Font font;
	sf::Text text;
	sf::RectangleShape borderText;
public:
	Button(std::string text, unsigned int characterSize, sf::Vector2f positionOfTheText, std::string fontFileLocation, sf::Vector2f positionOfBox, sf::Vector2f sizeOfTheBox);

	const sf::FloatRect& getBounds() const;

	void boldText();
	void unboldText();
	void render(sf::RenderTarget& target);
};
