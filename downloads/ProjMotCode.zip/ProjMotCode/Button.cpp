#include "Button.h"
Button::Button(std::string text, unsigned int characterSize, sf::Vector2f positionOfTheText, std::string fontFileLocation, sf::Vector2f positionOfBox, sf::Vector2f sizeOfTheBox) {
	this->font.loadFromFile(fontFileLocation);

	this->text.setCharacterSize(characterSize);
	this->text.setFillColor(sf::Color::White);
	this->text.setFont(font);
	this->text.setPosition(positionOfTheText);
	this->text.setString(text);

	this->borderText.setSize(sizeOfTheBox);
	this->borderText.setFillColor(sf::Color(23, 23, 23, 123));
	this->borderText.setPosition(positionOfBox);
	this->borderText.setOutlineColor(sf::Color::Black);
	this->borderText.setOutlineThickness(1.f);
}

const sf::FloatRect& Button::getBounds() const {
	return this->borderText.getGlobalBounds();
}

void Button::boldText() {
	this->text.setStyle(sf::Text::Bold);
	this->text.setFillColor(sf::Color(170, 170, 170, 255));
	this->borderText.setFillColor(sf::Color(23, 23, 23, 67));
}

void Button::unboldText() {
	this->text.setStyle(sf::Text::Regular);
	this->borderText.setFillColor(sf::Color(23, 23, 23, 123));
	this->text.setFillColor(sf::Color::White);
}
void Button::render(sf::RenderTarget& target) {
	target.draw(borderText);
	target.draw(text);
}