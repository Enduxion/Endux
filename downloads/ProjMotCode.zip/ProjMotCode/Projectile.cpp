#include "Projectile.h"
#define PI 3.1415926
// Private Functions
void Projectile::initProjectile(sf::Vector2f iP) {

	this->finished = false;
	this->prevT = 0.f;

	sf::CircleShape Tprojectile;
	Tprojectile.setRadius(3.f);
	Tprojectile.setFillColor(sf::Color::Black);
	Tprojectile.setPosition(iP);

	this->line.push_back(Tprojectile);
}
// Public Functions
void Projectile::update(float newX, int windowsY) {
	if (newX >= 1149) {
		this->finished = true;
		return;
	}
	this->X = newX;
	float firstComp = float(tan(double(this->iAngle)) * this->X);
	float secondComp = float((g * pow(this->X, 2) / (2 * pow(this->iVelocity * cos(double(iAngle)), 2))));
	this->Y = windowsY - (firstComp - secondComp);
	if (Y > float(windowsY)) {
		this->finished = true;
		return;
	}
	sf::CircleShape Tprojectile;
	Tprojectile.setRadius(3.f);
	Tprojectile.setFillColor(sf::Color::Black);
	Tprojectile.setPosition(sf::Vector2f(this->X, this->Y));

	this->line.push_back(Tprojectile);
	this->prevT++;
}
void Projectile::render(sf::RenderTarget& target) {
	for (int i = 0; i < line.size(); i++) {
		target.draw(this->line.at(i));
	}
}
// Constructors and Destructors
Projectile::Projectile(float angle, float iVelocity, sf::Vector2f initialPosition, int windowsY)
	:iAngle(angle), iVelocity(iVelocity) {
	this->Y = windowsY;
	this->iAngle = (iAngle / 180) * PI;
	this->initProjectile(initialPosition);
}
Projectile::~Projectile() {}
