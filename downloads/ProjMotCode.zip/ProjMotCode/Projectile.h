#pragma once
#include"TextBox.h"
#define g 9.8
class Projectile
{
private:
	float iAngle, iVelocity;
	float X, Y, prevT;
	bool finished;

	std::vector<sf::CircleShape> line;

	// Private Functions
	void initProjectile(sf::Vector2f iP);
public:
	// Public Functions
	inline bool getFinished() { return this->finished; }
	inline float getPrevT() { return this->prevT; }
	void update(float newX, int windowsY);
	void render(sf::RenderTarget& target);
	// Constructor & Destructor
	Projectile(const float angle, const float iVelocity, sf::Vector2f initialPosition, int windowsY);
	virtual ~Projectile();
};

