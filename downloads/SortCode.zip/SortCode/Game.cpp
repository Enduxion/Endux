#include "Game.h"
// Initialization
void Game::initVar()
{
	this->window = nullptr;
	this->bSort = false;
}
void Game::initWindow()
{
	this->videoMode.height = 600;
	this->videoMode.width = 800;
	this->window = new sf::RenderWindow(this->videoMode, "Game", sf::Style::Close | sf::Style::Titlebar | sf::Style::Fullscreen);
	this->window->setFramerateLimit(60);
}

void Game::initBox()
{
	sf::RectangleShape rs;
	rs.setFillColor(sf::Color::Black);
	for (unsigned i = 0; i < this->window->getSize().x; i+=2) {
		this->heightOfBoxes.push_back(exp(sin(i) * 10));
	}
	int count = 0;
	for (auto& e : this->heightOfBoxes) {
		rs.setSize(sf::Vector2f(2.f, static_cast<float>(e)));
		rs.setPosition(sf::Vector2f(static_cast<float>(count), static_cast<float>(this->window->getSize().y - e)));
		this->boxes.push_back(rs);
		count+=2;
	}
}

void Game::sort()
{
	for (int i = 0; i < this->heightOfBoxes.size() - 1; i++) {
		if (heightOfBoxes[i] < heightOfBoxes[i + 1]) {
			swap(i);
		}
	}
}

void Game::swap(const int i)
{
	int tmp = heightOfBoxes[i];
	heightOfBoxes[i] = heightOfBoxes[i + 1];
	heightOfBoxes[i + 1] = tmp;

	sf::Vector2f tmpS = this->boxes[i].getSize();
	this->boxes[i].setSize(this->boxes[i + 1].getSize());
	this->boxes[i + 1].setSize(tmpS);
	
	sf::Vector2f tmpPos = this->boxes[i].getPosition();
	this->boxes[i].setPosition(this->boxes[i].getPosition().x, this->boxes[i + 1].getPosition().y);
	this->boxes[i + 1].setPosition(this->boxes[i + 1].getPosition().x, tmpPos.y);
}

void Game::run()
{
	while (this->window->isOpen()) {
		this->update();
		this->render();
	}
}
void Game::gamePollEvent()
{
	// 
	while (this->window->pollEvent(this->ev))
	{
		switch (this->ev.type) {
		case sf::Event::Closed:
			this->window->close();
			break;
		case sf::Event::KeyPressed:
			if (this->ev.key.code == sf::Keyboard::R) {
				this->boxes.clear();
				this->heightOfBoxes.clear();
				this->initBox();
				this->bSort = false;
			}
			else if (this->ev.key.code == sf::Keyboard::S) {
				this->bSort = true;
			}
		}
	}
}
void Game::update()
{
	this->gamePollEvent();
	if (bSort)
		this->sort();
}
void Game::render()
{
	this->window->clear(sf::Color::White);
	for (auto& e : this->boxes) {
		this->window->draw(e);
	}
	this->window->display();
}
// Constructor and Destructor
Game::Game()
{
	this->initVar();
	this->initWindow();
	this->initBox();
}
Game::~Game()
{
	delete this->window;
}