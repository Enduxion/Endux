#pragma once
#include<iostream>
#include<vector>
#include<ctime>
#include<cstdlib>
#include<conio.h>
#include<math.h>
#include"SFML\System.hpp"
#include"SFML\Network.hpp"
#include"SFML\Window.hpp"
#include"SFML\Graphics.hpp"
#include<windows.h>
class Game
{
private:
	sf::RenderWindow* window;
	sf::Event ev;
	sf::VideoMode videoMode;
	bool bSort;
	std::vector<sf::RectangleShape> boxes;
	std::vector<int> heightOfBoxes;

	void initVar();
	void initWindow();
	void initBox();
	void sort();
	void swap(const int i);
public:
	Game();
	~Game();
	void run();
	void update();
	void render();
	void gamePollEvent();
};

