#pragma once
#include "Applications.h"
#include "Settings.h"
class N_Administrator
{
private:
	std::string userName;
	std::string password;
protected:
	Applications* app;
	Settings* settings;

	void initUser();
	virtual void mainMenu();
	void colorShifter();
public:
	N_Administrator(std::string _userName, std::string _password);
	void restart();
	virtual ~N_Administrator();
};

