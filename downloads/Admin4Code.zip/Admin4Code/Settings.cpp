#include "pch.h"
#include "Settings.h"
// Initializations
void Settings::initSettings()
{
	std::string tmp;
	// Getting all usernames from file to a vector. FileLocation: ./User/UserList.txt
	std::ifstream GetAllUserName("./Users/UserList.txt");
	while (std::getline(GetAllUserName, tmp))
	{
		this->AllUsers.push_back(tmp);
	}
	GetAllUserName.close();
	// Getting all passwords from file to a vector. FileLocation: ./User/Password.txt
	std::ifstream GetAllUserPassword("./Users/Password.txt");
	while (std::getline(GetAllUserPassword, tmp))
	{
		this->AllPasswords.push_back(tmp);
	}
	GetAllUserPassword.close();
}
void Settings::mainMenu()
{
	do {
		system("cls");
		std::cout << "----------------------\n";
		std::cout << "U. User Settings\nT. Theme\nC. Computer Settings\nB. Back\n";
		std::cout << "----------------------\n";
		char dec = toupper(_getche());
		if (dec == 'U') {
			this->userSettings();
		}
		else if (dec == 'T') {
			this->themeSettings();
		}
		else if (dec == 'C') {
			this->computerSettings();
		}
		else if (dec == 'B') {
			system("cls");
			break;
		}
	} while (1);
}
void Settings::userSettings()
{
	do {
		system("cls");
		std::cout << "---------------------\n";
		std::cout << "U. Change UserName\nP. Change Password\nB. Back\n";
		std::cout << "---------------------\n";
		char dec = toupper(_getche());
		if (dec == 'U') {
			this->changeUserName();
		}
		else if (dec == 'P') {
			this->changePassword();
		}
		else if (dec == 'B') {
			break;
		}
		else {
			continue;
		}
	} while (1);
}
void Settings::themeSettings()
{
	do {
		system("cls");
		std::cout << "---------------------\n";
		std::cout << "F. Change Foreground color\nB. Change Background color\nS. Schemes\nQ. Quit\n";
		std::cout << "---------------------\n";
		char dec = toupper(_getch());
		if (dec == 'F') {
			this->foreground();
		}
		else if (dec == 'B') {
			this->background();
		}
		else if (dec == 'S') {
			this->schemes();
		}
		else if (dec == 'Q') {
			break;
		}
		else {
			continue;
		}
	} while (1);
}
void Settings::computerSettings()
{
	do {
		system("cls");
		std::cout << "---------------------\n";
		std::cout << "F. Format Your Disk\nB. Back\n";
		std::cout << "---------------------\n";
		char dec = toupper(_getch());
		if (dec == 'F') {
			this->removeYourContent();
			break;
		}
		else if (dec == 'B') {
			system("cls");
			break;
		}
	} while (1);
}
// User Settings 
void Settings::changeUserName()
{
	do {
		system("cls");
		std::cout << "Change UserName\n";
		std::cout << "\nCurrent UserName: " << this->UserName;
		std::cout << "\nC. Change\nB. Back";
		char dec = toupper(_getche());
		if (dec == 'C') {
			system("cls");
			std::string newName, password;
			bool checkIfNameIsAvailable = true;
			std::cout << "Enter your password: ";
			std::getline(std::cin, password);
			if (password != this->Password)
			{
				std::cout << "Password incorrect";
				_getche();
				continue;
			}
			std::cout << "New Username: ";
			std::getline(std::cin, newName);
			for (unsigned i = 0; i < this->AllUsers.size(); i++) {
				if (newName == AllUsers.at(i))
					checkIfNameIsAvailable = false;
			}
			if (!checkIfNameIsAvailable)
			{
				system("cls");
				std::cout << "Name Not Available, Other users have same names.";
				_getche();
				continue;
			}
			if (newName.length() < 3) {
				system("cls");
				std::cout << "Name too short. Please Enter more than 3 characters\n";
				_getche();
				continue;
			}
			std::string tmp;
			std::string newText = ""; // For saving username in a file without changing other usernames
			std::ifstream getUserName("./Users/UserList.txt");
			while (std::getline(getUserName, tmp))
			{
				if (tmp == this->UserName)
					newText += newName + "\n";
				else
					newText += tmp + "\n";
			}
			getUserName.close();
			std::ofstream SaveChanges("./Users/UserList.txt");
			SaveChanges << newText;
			SaveChanges.close();

			// Changing All Files and folders name according to the users New name
			// Explorer's Username change
			std::string ExplorerOldName = "Explorer\\" + this->UserName;
			const char* ExplorerOldNameChar = ExplorerOldName.c_str();
			std::string ExplorerNewName = "Explorer\\" + newName;
			const char* ExplorerNewNameChar = ExplorerNewName.c_str();
			rename(ExplorerOldNameChar, ExplorerNewNameChar);
			// File name changes in [./UserData]
			std::string FileNumberOldName = "UserData\\" + this->UserName + " fileNumber.txt";
			std::string FileNamedAsUserName = "UserData\\" + this->UserName + ".txt";
			std::string FileNumberNewName = "UserData\\" + newName + " fileNumber.txt";
			std::string FileNamedAsUserNameNew = "UserData\\" + newName + ".txt";
			std::string ThemeOldName = "UserData\\" + this->UserName + " Theme.txt";
			std::string ThemeNewName = "UserData\\" + newName + " Theme.txt";
			// In Const Char* form
			const char* ThemeOldNameChar = ThemeOldName.c_str();
			const char* ThemeNewNameChar = ThemeNewName.c_str();
			const char* FileNumberOldNameChar = FileNumberOldName.c_str();
			const char* FileNumberNewNameChar = FileNumberNewName.c_str();
			const char* FileNamedAsUserNameChar = FileNamedAsUserName.c_str();
			const char* FileNamedAsUserNameNewChar = FileNamedAsUserNameNew.c_str();
			// Changes
			rename(FileNumberOldNameChar, FileNumberNewNameChar);
			rename(FileNamedAsUserNameChar, FileNamedAsUserNameNewChar);
			rename(ThemeOldNameChar, ThemeNewNameChar);
			LogError::setLog(this->UserName + " changed username to " + newName);
			std::cout << "Changes needs Restart to be applied";
			_getche();
			this->restart();
		}
		else if (dec == 'B')
		{
			break;
		}
	} while (1);
}
void Settings::changePassword()
{
	do {
		system("cls");
		std::cout << "Change Password\n\nUserName: " << this->UserName << std::endl;
		std::cout << "C. Change password\nB. Back";
		char dec = toupper(_getche());
		if (dec == 'C')
		{
			system("cls");
			std::string passwordOld;
			std::string passwordNew;
			std::cout << "Enter your old password: ";
			std::getline(std::cin, passwordOld);
			if (this->Password == passwordOld)
			{
				std::cout << "Enter your new Password: ";
				std::getline(std::cin, passwordNew);
				std::ifstream getPassword("./Users/Password.txt");

				if (passwordNew.length() < 4) {
					system("cls");
					std::cout << "Password too short. Please Enter more than 4 characters\n";
					_getche();
					continue;
				}
				std::string tmp, newFile = "";
				while (std::getline(getPassword, tmp))
				{
					if (tmp == this->Password)
						newFile += passwordNew + "\n";
					else
						newFile += tmp + "\n";
				}
				getPassword.close();
				std::ofstream savePassword("./Users/Password.txt");
				savePassword << newFile;
				savePassword.close();
				system("cls");
				std::cout << "Password Changed Successfully\nA Restart is reqiured";
				_getche();
				restart();
			}
			else
			{
				std::cout << "Password Does not match please try again";
				_getche();
				continue;
			}
		}
		else if (dec == 'B')
		{
			break;
		}
	} while (1);
}
// Computer Settings
void Settings::removeYourContent()
{
	do {
		system("cls");
		std::cout << "Do you really want to remove all of your file data(Y/N)\n";
		char dec = toupper(_getch());
		if (dec == 'Y') {
			std::string resetNametxt, resetNameFilenumbertxt, resetThemetxt, resetFromExplorer;
			bool containsSpace = false;
			for (unsigned i = 0; i < UserName.length(); i++)
			{
				if (UserName[i] == ' ') {
					containsSpace = true;
					resetNametxt = "UserData\\" + UserName + ".txt";
					resetNameFilenumbertxt = "UserData\\" + UserName + " fileNumber.txt";
					resetThemetxt = "UserData\\" + UserName + " Theme.txt";
					resetFromExplorer = "rmdir Explorer\\\"" + UserName + "\" /Q /S";
					break;
				}
			}
			if (!containsSpace) {
				resetNametxt = "UserData\\" + UserName + ".txt";
				resetNameFilenumbertxt = "UserData\\" + UserName + " fileNumber.txt";
				resetThemetxt = "UserData\\" + UserName + " Theme.txt";
				resetFromExplorer = "rmdir Explorer\\" + UserName + " /Q /S";
			}
			std::ofstream nametxt(resetNametxt);
			nametxt << "";
			nametxt.close();

			std::ofstream nameFileNumbertxt(resetNameFilenumbertxt);
			nameFileNumbertxt << "";
			nameFileNumbertxt.close();

			std::ofstream themetxt(resetThemetxt);
			themetxt << "7\n0";
			themetxt.close();

			system(resetFromExplorer.c_str());

			// Make Empty Files
			std::string explorerName, explorerNamePassword;
			std::string mkdirText = "mkdir ";

			bool isSpace = false;
			for (auto& i : UserName) {
				if (i == ' ') {
					explorerName = mkdirText + "Explorer\\\"" + UserName + "\"\\Game";
					explorerNamePassword = mkdirText + "Explorer\\\"" + UserName + "\"\\\"Password Saver\"";
					isSpace = true;
					break;
				}
			}
			if (!isSpace) {
				explorerName = mkdirText + "Explorer\\" + UserName + "\\Game";
				explorerNamePassword = mkdirText + "Explorer\\" + UserName + "\\\"Password Saver\"";
			}

			// Make Files in Explorer
			system((explorerName.c_str()));
			system((explorerNamePassword).c_str());

			LogError::setLog(this->UserName + " formatted their disk");
			// Removed
			std::cout << "Removed all the data\nRestarting\n";
			Sleep(1000);
			this->restart();
		}
		else if (dec == 'N') {
			std::cout << "Nothing Changed!!";
			_getche();
			break;
		}
		else {
			continue;
		}
	} while (1);
}
// Theme Settings
void Settings::foreground()
{
	std::string pathOfTheThemeFile = "./UserData/" + this->UserName + " Theme.txt";
	std::string backGroundColor, foreGroundColor;
	do {
		system("cls");
		// Importing the BackGround Color
		std::ifstream importcolor(pathOfTheThemeFile);
		importcolor >> foreGroundColor;
		importcolor >> backGroundColor;
		importcolor.close();
		std::cout << "1. White\n2. Bright White\n3. Grey\n4. Yellow\n5. Green\n6. Blue\n7. red\n8. Black\nB. Back";
		char dec = toupper(_getch());
		system("cls");
		if (dec == '1') {
			if (backGroundColor != "7" && backGroundColor != "F") {
				std::string newText = "color " + backGroundColor + "7";
				system(newText.c_str());
				std::cout << "Color set!";
				foreGroundColor = "7";
				_getche();
				break;
			}
			else {
				std::cout << "The BackGround Color and foreGround Color are same. Please choose different color";
				_getche();
				continue;
			}
		}
		else if (dec == '2') {
			if (backGroundColor != "7" && backGroundColor != "F") {
				std::string newText = "color " + backGroundColor + "F";
				system(newText.c_str());
				std::cout << "Color set!";
				foreGroundColor = "F";
				_getche();
				break;
			}
			else {
				std::cout << "The BackGround Color and foreGround Color are same. Please choose different color";
				_getche();
				continue;
			}
		}
		else if (dec == '3') {
			if (backGroundColor != "8") {
				std::string newText = "color " + backGroundColor + "8";
				system(newText.c_str());
				std::cout << "Color set!";
				foreGroundColor = "8";
				_getche();
				break;
			}
			else {
				std::cout << "The BackGround Color and foreGround Color are same. Please choose different color";
				_getche();
				continue;
			}
		}
		else if (dec == '4') {
			if (backGroundColor != "6") {
				std::string newText = "color " + backGroundColor + "6";
				system(newText.c_str());
				std::cout << "Color set!";
				foreGroundColor = "6";
				_getche();
				break;
			}
			else {
				std::cout << "The BackGround Color and foreGround Color are same. Please choose different color";
				_getche();
				continue;
			}
		}
		else if (dec == '5') {
			if (backGroundColor != "2") {
				std::string newText = "color " + backGroundColor + "2";
				system(newText.c_str());
				std::cout << "Color set!";
				foreGroundColor = "2";
				_getche();
				break;
			}
			else {
				std::cout << "The BackGround Color and foreGround Color are same. Please choose different color";
				_getche();
				continue;
			}
		}
		else if (dec == '6') {
			if (backGroundColor != "1") {
				std::string newText = "color " + backGroundColor + "1";
				system(newText.c_str());
				std::cout << "Color set!";
				foreGroundColor = "1";
				_getche();
				break;
			}
			else {
				std::cout << "The BackGround Color and foreGround Color are same. Please choose different color";
				_getche();
				continue;
			}
		}
		else if (dec == '7') {
			if (backGroundColor != "4") {
				std::string newText = "color " + backGroundColor + "4";
				system(newText.c_str());
				std::cout << "Color set!";
				foreGroundColor = "4";
				_getche();
				break;
			}
			else {
				std::cout << "The BackGround Color and foreGround Color are same. Please choose different color";
				_getche();
				continue;
			}
		}
		else if (dec == '8') {
			if (backGroundColor != "0") {
				std::string newText = "color " + backGroundColor + "0";
				system(newText.c_str());
				std::cout << "Color set!";
				foreGroundColor = "0";
				_getche();
				break;
			}
			else {
				std::cout << "The BackGround Color and foreGround Color are same. Please choose different color";
				_getche();
				continue;
			}
		}
		else if (dec == 'B') {
			break;
		}
		else {
			continue;
		}
	} while (1);
	std::ofstream saveTheme(pathOfTheThemeFile);
	saveTheme << foreGroundColor << "\n" << backGroundColor;
	saveTheme.close();
}
void Settings::background()
{
	std::string pathOfTheThemeFile = "./UserData/" + this->UserName + " Theme.txt";
	std::string backGroundColor, foreGroundColor;
	do {
		system("cls");
		// Importing the BackGround Color
		std::ifstream importcolor(pathOfTheThemeFile);
		importcolor >> foreGroundColor;
		importcolor >> backGroundColor;
		importcolor.close();
		std::cout << "1. White\n2. Bright White\n3. Grey\n4. Yellow\n5. Green\n6. Blue\n7. red\n8. Black\nB. Back";
		char dec = toupper(_getch());
		system("cls");
		if (dec == '1') {
			if (foreGroundColor != "7" && foreGroundColor != "F") {
				std::string newText = "color 7" + foreGroundColor;
				system(newText.c_str());
				std::cout << "Color set!";
				backGroundColor = "7";
				_getche();
				break;
			}
			else {
				std::cout << "The BackGround Color and foreGround Color are same. Please choose different color";
				_getche();
				continue;
			}
		}
		else if (dec == '2') {
			if (foreGroundColor != "7" && foreGroundColor != "F") {
				std::string newText = "color F" + foreGroundColor;
				system(newText.c_str());
				std::cout << "Color set!";
				backGroundColor = "F";
				_getche();
				break;
			}
			else {
				std::cout << "The BackGround Color and foreGround Color are same. Please choose different color";
				_getche();
				continue;
			}
		}
		else if (dec == '3') {
			if (foreGroundColor != "8") {
				std::string newText = "color 8" + foreGroundColor;
				system(newText.c_str());
				std::cout << "Color set!";
				backGroundColor = "8";
				_getche();
				break;
			}
			else {
				std::cout << "The BackGround Color and foreGround Color are same. Please choose different color";
				_getche();
				continue;
			}
		}
		else if (dec == '4') {
			if (foreGroundColor != "6") {
				std::string newText = "color 6" + foreGroundColor;
				system(newText.c_str());
				std::cout << "Color set!";
				backGroundColor = "6";
				_getche();
				break;
			}
			else {
				std::cout << "The BackGround Color and foreGround Color are same. Please choose different color";
				_getche();
				continue;
			}
		}
		else if (dec == '5') {
			if (foreGroundColor != "2") {
				std::string newText = "color 2" + foreGroundColor;
				system(newText.c_str());
				std::cout << "Color set!";
				backGroundColor = "2";
				_getche();
				break;
			}
			else {
				std::cout << "The BackGround Color and foreGround Color are same. Please choose different color";
				_getche();
				continue;
			}
		}
		else if (dec == '6') {
			if (foreGroundColor != "1") {
				std::string newText = "color 1" + foreGroundColor;
				system(newText.c_str());
				std::cout << "Color set!";
				backGroundColor = "1";
				_getche();
				break;
			}
			else {
				std::cout << "The BackGround Color and foreGround Color are same. Please choose different color";
				_getche();
				continue;
			}
		}
		else if (dec == '7') {
			if (foreGroundColor != "4") {
				std::string newText = "color 4" + foreGroundColor;
				system(newText.c_str());
				std::cout << "Color set!";
				backGroundColor = "4";
				_getche();
				break;
			}
			else {
				std::cout << "The BackGround Color and foreGround Color are same. Please choose different color";
				_getche();
				continue;
			}
		}
		else if (dec == '8') {
			if (foreGroundColor != "0") {
				std::string newText = "color 0" + foreGroundColor;
				system(newText.c_str());
				std::cout << "Color set!";
				backGroundColor = "0";
				_getche();
				break;
			}
			else {
				std::cout << "The BackGround Color and foreGround Color are same. Please choose different color";
				_getche();
				continue;
			}
		}
		else if (dec == 'B') {
			break;
		}
		else {
			continue;
		}
	} while (1);
	std::ofstream saveBGColor(pathOfTheThemeFile);
	saveBGColor << foreGroundColor << "\n" << backGroundColor;
	saveBGColor.close();
}
void Settings::schemes()
{
	std::string pathOfTheThemeFile = "./UserData/" + this->UserName + " Theme.txt";
	bool changed = true;
	std::string backGroundColor, foreGroundColor;
	do {
		system("cls");
		std::cout << "1. Light theme\n2. Dark Theme\n3. Hacker\nB. Back";
		char dec = toupper(_getche());
		if (dec == '1') {
			system("color F0");
			backGroundColor = "F";
			foreGroundColor = "0";
			system("cls");
			std::cout << "Changed Theme!!";
			_getche();
			break;
		}
		else if (dec == '2') {
			system("color 0F");
			backGroundColor = "0";
			foreGroundColor = "F";
			system("cls");
			std::cout << "Changed Theme!!";
			_getche();
			break;
		}
		else if (dec == '3') {
			backGroundColor = "0";
			foreGroundColor = "2";
			system("color 02");
			system("cls");
			std::cout << "Changed Theme!!";
			_getche();
			break;
		}
		else if (dec == 'B') {
			changed = false;
			break;
		}
		else {
			changed = false;
			continue;
		}
	} while (1);
	if (changed) {
		std::ofstream openText(pathOfTheThemeFile);
		openText << foreGroundColor << "\n" << backGroundColor;
		openText.close();
	}
}
// Frequently Used Functions
void Settings::restart()
{
	system("cls");
	std::string RestartString = "Restarting......";
	for (unsigned i = 0; i < RestartString.length(); i++) {
		std::cout << RestartString.at(i);
		this->colorShifter();
	}
	std::string  restartText = "start ";
	bool isSpaceDetected = false;
	unsigned positionOfBS = 0;
	char openExe[MAX_PATH];
	DWORD size = GetModuleFileNameA(NULL, openExe, MAX_PATH);
	for (int i = 0; i < MAX_PATH; i++)
	{
		if (openExe[i] == NULL)
			break;
		else if (openExe[i] == '\\' && isSpaceDetected) {
			positionOfBS = i + 1;
			restartText += "\"";
			restartText += openExe[i];
			isSpaceDetected = false;
		}
		else if (openExe[i] == '\\' && !isSpaceDetected) {
			positionOfBS = i + 1;
			restartText += openExe[i];
		}
		else if (openExe[i] == ' ') {
			restartText += openExe[i];
			if (!isSpaceDetected) {
				isSpaceDetected = true;
				restartText.insert(positionOfBS + 6, "\"");
			}
		}
		else {
			restartText += openExe[i];
		}
	}
	LogError::setLog(this->UserName + " restarted the PC");
	system((restartText).c_str());
	exit(0);
}
void Settings::colorShifter()
{
	int color = rand() % 7;
	switch (color) {
	case 0:
		system("color 7");
		break;
	case 1:
		system("color 1");
		break;
	case 2:
		system("color 2");
		break;
	case 3:
		system("color 3");
		break;
	case 4:
		system("color 4");
		break;
	case 5:
		system("color 5");
		break;
	case 6:
		system("color 6");
		break;
	}
}
// Constructors and destructors
Settings::Settings(std::string& UserName, std::string& Password)
{
	this->UserName = UserName;
	this->Password = Password;
	this->mainMenu();
}
Settings::~Settings()
{

}