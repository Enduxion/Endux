#pragma once
#include "Applications.h"
#include "A_Settings.h"
class Administrator
{
private:
	std::string userName;
	std::string password;
protected:
	Applications *app;
	A_Settings* settings;
	void initUser();
	virtual void mainMenu();
	void colorShifter();
public:
	Administrator(std::string _userName, std::string _password);
	void restart();
	virtual ~Administrator();
};

