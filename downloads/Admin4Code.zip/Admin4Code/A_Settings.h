#pragma once
#include"LogError.h"
#include"IfReseted.h"
class A_Settings
{
private:
	std::string UserName, Password;
	std::vector<std::string> AllUsers, AllPasswords, AllTags;
	// Initialize all Settings
	void initSettings();
	void mainMenu();
	// Real Settings :)
	void userSettings();
	void themeSettings();
	void computerSettings();
	// Settings inside theme Settings
	void foreground();
	void background();
	void schemes();
	// Settings inside user Settings
	void changeUserName();
	void changePassword();
	void changePermission();
	void addUser();
	void removeUser();
	// Settings inside computer settings
	void resetComputer();
	void formatDisk();
	void removeAllUsers();
	void makeAllUsersNonAdmin();
	void removeLog();
	void resetSettingsToDefault();
	// For Restarting
	void restart();
	void colorShifter();
	// For Fast use
	void removeASpecificUser(std::string& name);
	void formatASpecificData(std::string& name);
	void makeASpecificUser(std::string name, std::string password, std::string tag);
public:
	A_Settings(std::string currentUserName, std::string currentPassword);
	~A_Settings();
};

