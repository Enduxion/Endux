#include "pch.h"
#include "Administrator.h"
//Initalization
void Administrator::initUser()
{
	std::string theColor1, theColor2, finalText;
	std::string openingColorText = "./UserData/" + this->userName + " Theme.txt";
	std::ifstream openColorText(openingColorText);
	openColorText >> theColor1 >> theColor2;
	openColorText.close();
	finalText = "color " + theColor2 + theColor1;
	system(finalText.c_str());
}
//Function
void Administrator::mainMenu()
{
	system("cls");
	LogError::setLog("Logged in as " + this->userName);

	Sleep(200);
	do {
		system("cls");
		std::cout << "----------------------\n";
		std::cout << "A. Applications\nS. Settings\nW. Switch User\nR. Restart\nQ. Shut Down\n";
		std::cout << "----------------------\n";
		char dec = _getche();
		if (dec == 'A' || dec == 'a') {
			this->app = new Applications(this->userName, "Admin");
			delete this->app;
		}
		else if (dec == 'S' || dec == 's') {
			this->settings = new A_Settings(this->userName, this->password);
			delete this->settings;
		}
		else if (dec == 'W' || dec == 'w') {
			system("cls");
			LogError::setLog(this->userName + " switched account");
			break;
		}
		else if (dec == 'R' || dec == 'r') {
			this->restart();
		}
		else if (dec == 'Q' || dec == 'q') {
			system("cls");
			std::string shuttingSrc = "Shutting Down..";
			for (unsigned i = 0; i < shuttingSrc.length(); i++) {
				std::cout << shuttingSrc.at(i);
				Sleep(400);
			}
			LogError::setLog("PC was shut down by " + this->userName);
			exit(0);
		}
		else {
			continue;
		}
	} while (1);
}
void Administrator::restart()
{
	system("cls");
	std::string RestartString = "Restarting......";
	for (unsigned i = 0; i < RestartString.length(); i++) {
		std::cout << RestartString.at(i);
		this->colorShifter();
	}
	std::string  restartText = "start ";
	bool isSpaceDetected = false;
	unsigned positionOfBS = 0;
	char openExe[MAX_PATH];
	DWORD size = GetModuleFileNameA(NULL, openExe, MAX_PATH);
	for (int i = 0; i < MAX_PATH; i++)
	{
		if (openExe[i] == NULL)
			break;
		else if (openExe[i] == '\\' && isSpaceDetected) {
			positionOfBS = i + 1;
			restartText += "\"";
			restartText += openExe[i];
			isSpaceDetected = false;
		}
		else if (openExe[i] == '\\' && !isSpaceDetected) {
			positionOfBS = i + 1;
			restartText += openExe[i];
		}
		else if (openExe[i] == ' ') {
			restartText += openExe[i];
			if (!isSpaceDetected) {
				isSpaceDetected = true;
				restartText.insert(positionOfBS + 6, "\"");
			}
		}
		else {
			restartText += openExe[i];
		}
	}
	LogError::setLog(this->userName + " restarted the PC");
	system((restartText).c_str());
	exit(0);
}
void Administrator::colorShifter()
{
		int color = rand() % 7;
		switch (color) {
		case 0:
			system("color 7");
			break;
		case 1:
			system("color 1");
			break;
		case 2:
			system("color 2");
			break;
		case 3:
			system("color 3");
			break;
		case 4:
			system("color 4");
			break;
		case 5:
			system("color 5");
			break;
		case 6:
			system("color 6");
			break;
		}
}
//C&D
Administrator::Administrator(std::string _userName, std::string _password)
{
	this->userName = _userName;
	this->password = _password;
	this->initUser();
	this->mainMenu();
}
Administrator::~Administrator()
{

}