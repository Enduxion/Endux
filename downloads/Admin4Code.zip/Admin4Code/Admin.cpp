#include "pch.h"
#include "Admin.h"
//Initialization
void Admin::initUsers()
{
	std::string userImportTemp;
	std::ifstream userNameImport("./Users/UserList.txt");
	while (getline(userNameImport, userImportTemp)) {
		this->userList.push_back(userImportTemp);
		++userNumber;
	}// getting all user's name
	std::ifstream userTagImport("./Users/UserTag.txt");
	while (getline(userTagImport, userImportTemp)) {
		this->userTag.push_back(userImportTemp);
	}// getting all user's tag
	userTagImport.close();
	std::ifstream userPasswordImport("./Users/Password.txt");
	while (getline(userPasswordImport, userImportTemp)) {
		this->password.push_back(userImportTemp);
	}//getting all user's password
	userPasswordImport.close();
}
//Functions
void Admin::login()
{
	std::string loadingSrc = "-----------------\n|      PCS      |\n-----------------\n";
	do {
		system("color 7");
		bool administrator = false, logged = false;
		system("cls");
		std::cout << loadingSrc;
		std::cout << "User Name\n=>";
		getline(std::cin, this->currentUserName);
		LogError::setLog("User Entered name as " + this->currentUserName);
		std::cout << "Password\n=>";
		getline(std::cin, this->currentUserPassword);
		//UserName, Tag and Password checking
		for (unsigned i = 0; i < userNumber; i++) {
			if (this->currentUserName == this->userList[i] && this->currentUserPassword == this->password[i] && userTag[i] == "Admin") {
				administrator = true;
				logged = true;
				break;
			}
			else if (this->currentUserName == this->userList[i] && this->currentUserPassword == this->password[i] && userTag[i] == "N-Admin") {
				administrator = false;
				logged = true;
				break;
			} 
		}
		this->loggingAni();
		if (!logged) {
			std::cout << "\nWrong user data";
			LogError::setLog("Name: " + currentUserName + ". Wrong Data");
			_getche();
			continue;
		}
		else
			loggingIn(administrator);
	} while (1);
}
void Admin::loggingAni()
{
	system("cls");
	std::string ani = "Logging in...";
	for (unsigned i = 0; i < ani.length(); i++)
	{
		std::cout << ani[i];
		Sleep(20);
	}
}
void Admin::loggingIn(bool& administratorBool)
{
	if (administratorBool) {
		this->administrator = new Administrator(this->currentUserName, this->currentUserPassword);
		delete this->administrator;
	}
	else if (!administratorBool) {
		this->n_administrator = new N_Administrator(this->currentUserName, this->currentUserPassword);
		delete this->n_administrator;
	}
}
//constructor && destructor
Admin::Admin()
{
	IfReseted::init();
	if (IfReseted::wasReseted()) {
		std::cout << "-----------------\n";
		std::cout << "This Computer was reseted\nYour Username is: Admin\nYour Password is Admin\n";
		std::cout << "-----------------\n";
		_getche();
		IfReseted::changeValue(false);
		system("cls");
	}
	LogError::setLog("Pc was turned on");
	std::string loadingSrc = "-----------------\n|      PCS      |\n-----------------\n";
	for (unsigned i = 0; i < loadingSrc.length(); i++) {
		int color = rand() % 7;
		std::cout << loadingSrc[i];
		switch (color) {
		case 0:
			system("color 7");
			break;
		case 1:
			system("color 1");
			break;
		case 2:
			system("color 2");
			break;
		case 3:
			system("color 3");
			break;
		case 4:
			system("color 4");
			break;
		case 5:
			system("color 5");
			break;
		case 6:
			system("color 6");
			break;
		} // Color Swifter
		Sleep(10);
	}//Loading Screen
	system("color 7");
	this->initUsers();
}
Admin::~Admin()
{
	LogError::setLog("Pc was shut down unexpectedly!");
}
