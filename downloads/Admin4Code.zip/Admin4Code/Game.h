#pragma once
class Game
{
private:
	std::string currentUser, currentStat, currentGame;
	//Global Variable & Functions
	void Cls();
	void GlobalHs();
	void GlobalReset();

	bool gameOver;
	int X, Y, score;
	enum Direction {STOP = 0, LEFT, RIGHT, UP, DOWN};
	Direction dir;
	//Variable for Snake Game
	const int WD = 20, HG = 20;
	int tailLen, FX, FY;
	int tailX[100], tailY[100];
	//Variables for EAF
	const int Width = 40, Height = 25;
	int EnemyX[20] ,EnemyY[20];
	const int maxEnemies = 10;
	int countOfEnemies;
	//Variables for TTT
	char mark;
	char placeMark;
	int AplaceMark;
	std::string player1Name;
	std::string player2Name;
	std::vector<int> placedPlaces;
	char board[3][3] = {{' ' ,' ' ,' '},
		{' ' ,' ' ,' '},
		{' ', ' ', ' '}};
	
	//Function for Snake game
	void initSnake();
	void Input_Snake();
	void Render_Snake();
	void update_Snake();
	void run_Snake();
	//Function for EAF
	void initEAF();
	void Input_EAF();
	void Render_EAF();
	void update_EAF();
	void run_EAF();
	//TTT
	void initTTT();
	void bodyTTT();
	void RenderTTT();
	bool CheckForPlace();
	void placeMarker();
	bool CheckIfSomeOneWon();
	void runTTT();
public:
	Game(std::string _Username, std::string _Stat, std::string GamePlayed);
	~Game();
};

