#pragma once
#include"LogError.h"
class Settings
{
private:
	std::string UserName, Password;
	std::vector<std::string> AllUsers, AllPasswords;
public:
	void initSettings();
	void mainMenu();
	void userSettings();
	void computerSettings();
	void themeSettings();
	// UserSettings
	void changeUserName();
	void changePassword();
	// Theme settings
	void foreground();
	void background();
	void schemes();
	// Computer Settings
	void removeYourContent();
	// Frequently Used Functions
	void restart();
	void colorShifter();
	//Constructors and destructors
	Settings(std::string& UserName, std::string& Password);
	~Settings();
};

