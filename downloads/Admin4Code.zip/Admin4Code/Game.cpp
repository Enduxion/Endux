#include "pch.h"
#include "Game.h"
//Global
void Game::Cls()
{
	COORD Co;
	Co.X = 0;
	Co.Y = 0;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), Co);
}
void Game::GlobalHs()
{
	system("cls");
	std::string gameScoreString = "./Explorer/" + this->currentUser + "/Game/" + this->currentGame + ".txt";
	std::string showHighScore = "";
	std::ifstream Highscore(gameScoreString);
	Highscore >> showHighScore;
	Highscore.close();
	std::cout << "The Highscore is " << showHighScore << std::endl << "Press any key to continue";
	_getche();
}
void Game::GlobalReset()
{
	system("cls");
	std::string gameScoreString = "./Explorer/" + this->currentUser + "/Game/" + this->currentGame + ".txt";
	std::ofstream HighScoreReset(gameScoreString);
	HighScoreReset << "0";
	HighScoreReset.close();
	std::cout << "The HighScore is reseted\nPress any key to continue";
	_getche();
}
//Snake game
void Game::initSnake()
{
	this->gameOver = false;
	this->X = WD / 2;
	this->Y = HG / 2;
	this->score = 0;
	this->tailLen = 0;
	this->dir = STOP;
	do {
		this->FX = rand() % (this->WD-1);
		this->FY = rand() % this->HG;
	} while (this->FX <= 0);
}
void Game::Render_Snake()
{
	this->Cls();
	for (int i = 0; i < this->WD; i++)
		std::cout << '-';
	std::cout << std::endl;
	for (int i = 0; i < this->HG; i++)
	{
		for (int j = 0; j < this->WD; j++)
		{
			if (j == 0 || j == this->HG - 1)
				std::cout << '|';
			else if (j == this->X && i == this->Y)
				std::cout << '@';
			else if (j == this->FX && i == this->FY)
				std::cout << 'c';
			else {
				bool printTail = false;
				for (int k = 0; k < this->tailLen; k++)
				{
					if (this->tailX[k] == j && this->tailY[k] == i)
					{
						std::cout << 'o';
						printTail = true;
						break;
					}
				}
				if (!printTail)
					std::cout << ' ';
			}
		}
		std::cout << std::endl;
	}
	for (int i = 0; i < WD; i++)
		std::cout << '-';
	std::cout << "\nScore: " << score;
}
void Game::Input_Snake()
{
	if (_kbhit())
	{
		switch (_getch())
		{
		case 'a':
			if (this->dir != RIGHT)
				this->dir = LEFT;
			break;
		case 'd':
			if (this->dir != LEFT)
				this->dir = RIGHT;
			break;
		case 'w':
			if (this->dir != DOWN)
				this->dir = UP;
			break;
		case 's':
			if (this->dir != UP)
				this->dir = DOWN;
			break;
		case 'q':
			this->gameOver = true;
			break;
		}
	}
}
void Game::update_Snake()
{
	int prevX = this->tailX[0];
	int prevY = this->tailY[0];
	this->tailX[0] = X;
	this->tailY[0] = Y;
	int prevX2, prevY2;
	for (int i = 1; i < this->tailLen; i++)
	{
		prevX2 = this->tailX[i];
		prevY2 = this->tailY[i];
		this->tailX[i] = prevX;
		this->tailY[i] = prevY;
		prevX = prevX2;
		prevY = prevY2;
	}
	switch (this->dir)
	{
	case LEFT:
		this->X--;
		break;
	case RIGHT:
		this->X++;
		break;
	case UP:
		this->Y--;
		break;
	case DOWN:
			this->Y++;
			break;
	}

	//collision
	if (this->FX == this->X && this->FY == this->Y)
	{
		this->score++;
		this->tailLen++;
		bool loop = false;
		do {
			bool loop = false;
			this->FX = rand() % (WD - 1);
			this->FY = rand() % HG;
			for (int i = 0; i < tailLen; i++)
			{
				if (tailX[i] == FX && tailY[i] == FY)
					loop = true;
			}
		} while (this->FX <= 0 || loop);
		
	}

	if (this->X <= 0)
		this->X = this->WD - 2;
	else if (this->X >= this->WD-1)
		this->X = 1;
	if (this->Y < 0)
		this->Y = this->HG;
	else if (this->Y > HG-1)
		this->Y = 0;

	for (int i = 1; i < this->tailLen; i++) {
		if (this->tailX[i] == X && this->tailY[i] == Y)
			this->gameOver = true;
	}
}
void Game::run_Snake()
{
	do {
		system("cls");
		std::cout << "---------------\n|    Snake    |\n---------------\n";
		std::cout << "P. Play\nH. HighScore\nR. Reset Highscore\nB. back\n";
		char dec = toupper(_getche());
		if (dec == 'P') {
			this->initSnake();
			system("cls");
			while (!gameOver)
			{
				this->Render_Snake();
				Sleep(25);
				if (dir == UP || DOWN)
					Sleep(45);
				this->Input_Snake();
				this->update_Snake();
			}
			if (gameOver)
			{
				std::string gameScoreString = "./Explorer/" + this->currentUser + "/Game/" + this->currentGame + ".txt";
				std::ifstream getHighScore(gameScoreString);
				int prevScore = 0;
				getHighScore >> prevScore;
				getHighScore.close();
				if (score > prevScore)
				{
					std::ofstream setHighscore(gameScoreString);
					setHighscore << score;
					setHighscore.close();
				}
			}
		}
		else if (dec == 'H') {
			this->GlobalHs();
		}
		else if (dec == 'R') {
			this->GlobalReset();
		}
		else if (dec == 'B') {
			break;
		}
	} while (1);
}
//EAF
void Game::initEAF()
{
	this->gameOver = false;
	this->X = this->Width / 2;
	this->Y = this->Height / 2;
	this->countOfEnemies = 1;
	do {
		this->EnemyX[0] = rand() % Width - 1;
		this->EnemyY[0] = rand() % Height;
	} while (this->EnemyX <= 0);
	this->score = 0;
	this->dir = STOP;
}
void Game::Render_EAF()
{
	this->Cls();
	for (int i = 0; i < this->Width; i++)
		std::cout << '-';
	std::cout << std::endl;
	for (int i = 0; i < this->Height; i++)
	{
		for (int j = 0; j < this->Width; j++)
		{
			if (j == this->Width - 1 || j == 0)
				std::cout << '|';
			else if (j == this->X && i == this->Y)
				std::cout << '@';
			else
			{
				bool printEnemies = false;
				for (int k = 0; k < countOfEnemies; k++)
				{
					if (j == EnemyX[k] && i == EnemyY[k])
					{
						std::cout << 'x';
						printEnemies = true;
					}
				}
				if (!printEnemies)
					std::cout << ' ';
			}
		}
		std::cout << std::endl;
	}
	for (int i = 0; i < this->Width; i++)
		std::cout << '-';
	std::cout << "\nScore: " << score;
}
void Game::Input_EAF()
{
	if (_kbhit())
	{
		switch (_getch())
		{
		case 'a':
			this->dir = LEFT;
			break;
		case 'd':
			this->dir = RIGHT;
			break;
		case 'w':
			this->dir = UP;
			break;
		case 's':
			this->dir = DOWN;
			break;
		case 'q':
			this->gameOver = true;
			break;
		}
	}
}
void Game::update_EAF()
{
	switch (this->dir)
	{
	case LEFT:
		X--;
		break;
	case RIGHT:
		X++;
		break;
	case UP:
		Y--;
		break;
	case DOWN:
		Y++;
		break;
	}
	for (int i = 0; i < countOfEnemies; i++)
	{
		if (X == EnemyX[i] && Y == EnemyY[i]) {
			do {
				EnemyX[i] = rand() % Width - 1;
				EnemyY[i] = rand() % Height;
				int GameEnder = rand() % 100;
				if (GameEnder > 90)
					gameOver = true;
			} while (EnemyX[i] <= 0);
			score++;
			if (countOfEnemies < maxEnemies) {
				++countOfEnemies;
				do {
					EnemyX[countOfEnemies - 1] = rand() % Width - 1;
					EnemyY[countOfEnemies - 1] = rand() % Height;
				} while (EnemyX[countOfEnemies - 1] <= 0);
			}
		}
	}
	if (X <= 0) X = Width - 2;
	else if (X >= Width- 1) X = 1;
	if (Y < 0) Y = Height;
	else if (Y >= Height + 1) Y = 0;
}
void Game::run_EAF()
{
	do {
		system("cls");
		std::cout << "-------------\n|    EAF    |\n-------------\n";
		std::cout << "P. Play\nH. Highscore\nR. Reset Highscore\nB. Back\n";
		char dec = toupper(_getche());
		if (dec == 'P')
		{
			this->initEAF();
			system("cls");
			while (!this->gameOver)
			{
				this->Render_EAF();
				Sleep(25);
				if (dir == UP || DOWN)
					Sleep(45);
				this->Input_EAF();;
				this->update_EAF();
			}
			if (gameOver)
			{
				std::string gameScoreString = "./Explorer/" + this->currentUser + "/Game/" + this->currentGame + ".txt";
				std::ifstream getHighScore(gameScoreString);
				int prevScore = 0;
				getHighScore >> prevScore;
				getHighScore.close();
				if (score > prevScore)
				{
					std::ofstream setHighscore(gameScoreString);
					setHighscore << score;
					setHighscore.close();
				}
			}
		}
		else if (dec == 'H')
			this->GlobalHs();
		else if (dec == 'R')
			this->GlobalReset();
		else if (dec == 'B')
			break;
	} while (1);
}
//TTT
bool Game::CheckForPlace()
{
	if (this->placeMark <= '0' || this->placeMark > '9')
		return false;
	for (unsigned i = 0; i < this->placedPlaces.size(); i++)
	{
		if (this->placedPlaces[i] == this->AplaceMark) {
			return false;
		}
	}
	return true;
}
bool Game::CheckIfSomeOneWon()
{
	this->RenderTTT();
	for (int i = 0; i < 3; i++)
	{
		if (board[i][0] == 'X' && board[i][0] == board[i][1] && board[i][2] == board[i][1])
		{
			system("cls");
			std::cout << player1Name << " Won\nPress any key to continue";
			_getche();
			return true;
		}
		else if (board[i][0] == 'O' && board[i][0] == board[i][1] && board[i][2] == board[i][1])
		{
			system("cls");
			std::cout << player2Name << " Won\nPress any key to continue";
			_getche();
			return true;
		}
		if (board[0][i] == 'X' && board[0][i] == board[1][i] && board[2][i] == board[1][i])
		{
			system("cls");
			std::cout << player1Name << " Won\nPress any key to continue";
			_getche();
			return true;
		}
		else if (board[0][i] == 'O' && board[0][i] == board[1][i] && board[2][i] == board[1][i])
		{
			system("cls");
			std::cout << player2Name << " Won\nPress any key to continue";
			_getche();
			return true;
		}
	}
	if (board[0][0] == 'X' && board[1][1] == 'X' && board[2][2] == 'X')
	{
		system("cls");
		std::cout << player1Name << " Won\nPress any key to continue";
		_getche();
		return true;
	}
	else if (board[0][0] == 'O' && board[1][1] == 'O' && board[2][2] == 'O')
	{
		system("cls");
		std::cout << player2Name << " Won\nPress any key to continue";
		_getche();
		return true;
	}
	else if (board[2][0] == 'X' && board[1][1] == 'X' && board[0][2] == 'X')
	{
		system("cls");
		std::cout << player1Name << " Won\nPress any key to continue";
		_getche();
		return true;
	}
	else if (board[2][0] == 'O' && board[1][1] == 'O' && board[2][0] == 'O')
	{
		system("cls");
		std::cout << player2Name << " Won\nPress any key to continue";
		_getche();
		return true;
	}
	return false;
}
void Game::placeMarker()
{
	if (this->placeMark < '4' && this->placeMark > '0')
	{
		if (board[0][this->AplaceMark - 1] == ' ')
			board[0][this->AplaceMark - 1] = this->mark;
	}
	else if (this->placeMark > '3' && this->placeMark < '7')
	{
		if (board[1][this->AplaceMark - 4] == ' ')
			board[1][this->AplaceMark - 4] = this->mark;
	}
	else if (this->placeMark > '6' && this->placeMark < ':')
	{
		if (board[2][this->AplaceMark - 7] == ' ')
			board[2][this->AplaceMark - 7] = this->mark;
	}
}
void Game::initTTT()
{
	std::cout << "Enter your name (Player 1): ";
	getline(std::cin, this->player1Name);
	std::cout << "Enter your name (Player 2): ";
	getline(std::cin, this->player2Name);
	std::cout << this->player1Name << " is X and " << this->player2Name << " is O\n";
	_getche();
	this->placedPlaces.clear();
	this->mark = 'X';
	this->placeMark = NULL;
	this->AplaceMark = 0;
}
void Game::runTTT()
{
	do {
		system("cls");
		std::cout << "---------------------\n|    Tic Tac Toe    |\n---------------------\n";
		std::cout << "P. Play\nB. Back";
		char dec = toupper(_getche());
		system("cls");
		if (dec == 'P')
		{
			this->initTTT();
			this->bodyTTT();
		}
		else if (dec == 'B')
		{
			system("cls");
			break;
		}
		else
		{
			continue;
		}
	} while (1);
}
void Game::bodyTTT()
{
	bool SomeOneWon = false;
	for (int i = 0; i < 9; i++)
	{
		this->RenderTTT();
		if (i % 2 == 0)
		{
			std::cout << this->player1Name << "'s turn" << std::endl;
			this->mark = 'X';
			this->placeMark = _getche();
			this->AplaceMark = this->placeMark - '0';
			if (!CheckForPlace()) {
				i--;
				continue;
			}
			else
			{
				this->placedPlaces.push_back(this->AplaceMark);
			}
			placeMarker();
		}
		else
		{
			std::cout << this->player2Name << "'s turn" << std::endl;
			this->mark = 'O';
			this->placeMark = _getche();
			this->AplaceMark = this->placeMark - '0';
			if (!CheckForPlace()) {
				i--;
				continue;
			}
			else
			{
				this->placedPlaces.push_back(this->AplaceMark);
			}
			placeMarker();
		}
		if (CheckIfSomeOneWon())
		{
			SomeOneWon = true;
			break;
		}
	}
	if (!SomeOneWon)
	{
		this->RenderTTT();
		std::cout << "This was a draw";
		_getche();
	}
	this->placedPlaces.clear();
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			board[i][j] = ' ';
		}
	}
}
void Game::RenderTTT()
{
	system("cls");
	std::cout << this->board[0][0] << " | " << this->board[0][1] << " | " << this->board[0][2] << std::endl;
	std::cout << "-----------" << std::endl;
	std::cout << this->board[1][0] << " | " << this->board[1][1] << " | " << this->board[1][2] << std::endl;
	std::cout << "-----------" << std::endl;
	std::cout << this->board[2][0] << " | " << this->board[2][1] << " | " << this->board[2][2] << std::endl;
}
//C&D
Game::Game(std::string _Username, std::string _Stat, std::string GamePlayed)
{
	this->currentUser = _Username;
	this->currentStat = _Stat;
	this->currentGame = GamePlayed;
	if (this->currentGame == "Snake")
	{
		this->run_Snake();
	}
	else if (GamePlayed == "EAF")
	{
		this->run_EAF();
	}
	else if (GamePlayed == "TTT")
	{
		this->runTTT();
	}
	else
	{
		std::cerr << "Game code changed please report to Unknown Temptation";
		exit(-9);
	}
}
Game::~Game()
{

}