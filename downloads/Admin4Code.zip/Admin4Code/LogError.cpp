#include "pch.h"
#include "LogError.h"

void LogError::setLog(std::string logMsg)
{
	time_t now;
	struct tm nowLocal;
	now = time(NULL);
	nowLocal = *localtime(&now);
	std::stringstream ss;
	ss << nowLocal.tm_year + 1900 << '-' << nowLocal.tm_mon << '-' << nowLocal.tm_mday << " " << nowLocal.tm_hour << ":" << nowLocal.tm_min << ":" << nowLocal.tm_sec << " Info : " << logMsg << std::endl;
	std::ofstream log("./Log/log.dat", std::ios::app);
	log << ss.str();
	log.close();
}