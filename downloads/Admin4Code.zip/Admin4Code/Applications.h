#pragma once
#include "Game.h"
class Applications
{
private:
	Game* game;
	std::string currentUser;
	std::string currentStat;

	std::string userName, Email = "NA", phoneNumber = "NA", password = "NA", dateOfBirth = "NA", RecoveryEmail = "NA";
	bool saved = false;
	bool RecoveryEmailCheck();
	bool emailCheck(std::string email);
	void phoneBasedLog();
	void bothBasedLog();
	void emailBasedLog();

	void calculation(const char oprtr);
	void calculation();
	void App_Calulator();
	void App_Explorer();
	void App_TextEditor();
	void App_PasswordSaver();
	void App_DateAndTime();
	void Cls();
public:
	void AppMainMenu();
	Applications(std::string currentUser, std::string currentStatus);
	~Applications();
};

