#pragma once

#include <iostream>
#include <vector>
#include <cstdlib>
#include <windows.h>
#include <array>
#include <ctime>
#include <fstream>
#include <conio.h>
#include <cmath>
#include <string>
#include <sstream>