#include "pch.h"
#include "Admin.h"
int main()
{
	system("cls");
	srand(static_cast<unsigned>(time(NULL)));
	Admin admin;
	admin.login();
	return 0;
}