#include "pch.h"
#include "IfReseted.h"

bool IfReseted::isReset = false;

void IfReseted::init()
{
	std::ifstream resetDatFile("./Log/reseted.dat");
	resetDatFile >> isReset;
	resetDatFile.close();
}
bool IfReseted::wasReseted()
{
	return isReset;
}
void IfReseted::changeValue(bool value)
{
	std::ofstream resetDatFile("./Log/reseted.dat");
	resetDatFile << value;
	resetDatFile.close();
}