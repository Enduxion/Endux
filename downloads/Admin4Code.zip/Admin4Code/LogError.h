#pragma once
class LogError
{
public:
	static void setLog(std::string logMsg);
};

