#include "pch.h"
#include "A_Settings.h"
// Initialize all Settings
void A_Settings::initSettings()
{
	std::string tmp;
	// Getting all usernames from file to a vector. FileLocation: ./User/UserList.txt
	std::ifstream GetAllUserName("./Users/UserList.txt");
	while (std::getline(GetAllUserName, tmp))
	{
		this->AllUsers.push_back(tmp);
	}
	GetAllUserName.close();
	// Getting all passwords from file to a vector. FileLocation: ./User/Password.txt
	std::ifstream GetAllUserPassword("./Users/Password.txt");
	while (std::getline(GetAllUserPassword, tmp))
	{
		this->AllPasswords.push_back(tmp);
	}
	GetAllUserPassword.close();
	// Getting all tag from file to a vector. FileLocation: ./User/UserTag.txt
	std::ifstream GetAllUserTag("./Users/UserTag.txt");
	while (std::getline(GetAllUserTag, tmp))
	{
		this->AllTags.push_back(tmp);
	}
	GetAllUserTag.close();
}
//Functions
void A_Settings::mainMenu()
{
	do {
		system("cls");
		std::cout << "----------------------\n";
		std::cout << "U. User Settings\nT. Theme\nC. Computer Settings\nB. Back\n";
		std::cout << "----------------------\n";
		char dec = toupper(_getche());
		if (dec == 'U') {
			this->userSettings();
		}
		else if (dec == 'T') {
			this->themeSettings();
		}
		else if (dec == 'C') {
			this->computerSettings();
		}
		else if (dec == 'B') {
			system("cls");
			break;
		}
	} while (1);
}
// Settings
void A_Settings::userSettings()
{
	do {
		system("cls");
		std::cout << "---------------------\n";
		std::cout << "U. Change UserName\nP. Change Password\nC. Change Permission\nA. Add User\nR. Remove User\nB. Back\n";
		std::cout << "---------------------\n";
		char dec = toupper(_getche());
		if (dec == 'U') {
			this->changeUserName();
		}
		else if (dec == 'P') {
			this->changePassword();
		}
		else if (dec == 'C') {
			this->changePermission();
		}
		else if (dec == 'A') {
			this->addUser();
		}
		else if (dec == 'R') {
			this->removeUser();
		}
		else if (dec == 'B') {
			break;
		}
		else {
			continue;
		}
	} while (1);
}
void A_Settings::themeSettings()
{
	do {
		system("cls");
		std::cout << "---------------------\n";
		std::cout << "F. Change Foreground color\nB. Change Background color\nS. Schemes\nQ. Quit\n";
		std::cout << "---------------------\n";
		char dec = toupper(_getch());
		if (dec == 'F') {
			this->foreground();
		}
		else if (dec == 'B') {
			this->background();
		}
		else if (dec == 'S') {
			this->schemes();
		}
		else if (dec == 'Q') {
			break;
		}
		else {
			continue;
		}
	} while (1);
}
void A_Settings::computerSettings()
{
	do {
		system("cls");
		std::cout << "---------------------\n";
		std::cout << "F. Format Disk (All users data erase)\nD. Remove all Users\nN. Make all Users non Admin\nT. Remove Log\nR. Reset Pc\nB. Back\n";
		std::cout << "---------------------\n";
		char dec = toupper(_getch());
		if (dec == 'F') {
			this->formatDisk();
			break;
		}
		else if (dec == 'D') {
			this->removeAllUsers();
			break;
		}
		else if (dec == 'N') {
			this->makeAllUsersNonAdmin();
			break;
		}
		else if (dec == 'T') {
			this->removeLog();
			break;
		}
		else if (dec == 'R') {
			this->resetComputer();
			break;
		}
		else if (dec == 'B') {
			system("cls");
			break;
		}
	} while (1);
}
// C&D
A_Settings::A_Settings(std::string currentUserName, std::string currentPassword)
{
	this->initSettings();
	this->UserName = currentUserName;
	this->Password = currentPassword;
	this->mainMenu();
}
A_Settings::~A_Settings()
{
	
}
// Settings inside User Settings
void A_Settings::changeUserName()
{
	do {
		system("cls");
		std::cout << "Change UserName\n";
		std::cout << "\nCurrent UserName: " << this->UserName;
		std::cout << "\nC. Change\nB. Back";
		char dec = toupper(_getche());
		if (dec == 'C') {
			system("cls");
			std::string newName, password;
			bool checkIfNameIsAvailable = true;
			std::cout << "Enter your password: ";
			std::getline(std::cin, password);
			if (password != this->Password)
			{
				std::cout << "Password incorrect";
				_getche();
				continue;
			}
			std::cout << "New Username: ";
			std::getline(std::cin, newName);
			for (unsigned i = 0; i < this->AllUsers.size(); i++) {
				if (newName == AllUsers.at(i))
					checkIfNameIsAvailable = false;
			}
			if (!checkIfNameIsAvailable)
			{
				system("cls");
				std::cout << "Name Not Available, Other users have same names.";
				_getche();
				continue;
			}
			if (newName.length() < 3) {
				system("cls");
				std::cout << "Name too short. Please Enter more than 3 characters\n";
				_getche();
				continue;
			}
			std::string tmp;
			std::string newText = ""; // For saving username in a file without changing other usernames
			std::ifstream getUserName("./Users/UserList.txt");
			while (std::getline(getUserName, tmp))
			{
				if (tmp == this->UserName)
					newText += newName + "\n";
				else
					newText += tmp + "\n";
			}
			getUserName.close();
			std::ofstream SaveChanges("./Users/UserList.txt");
			SaveChanges << newText;
			SaveChanges.close();

			LogError::setLog(this->UserName + " changed username to " + newName);

			// Changing All Files and folders name according to the users New name
			// Explorer's Username change
			std::string ExplorerOldName = "Explorer\\" + this->UserName;
			const char* ExplorerOldNameChar = ExplorerOldName.c_str();
			std::string ExplorerNewName = "Explorer\\" + newName;
			const char* ExplorerNewNameChar = ExplorerNewName.c_str();
			rename(ExplorerOldNameChar, ExplorerNewNameChar);
			// File name changes in [./UserData]
			std::string FileNumberOldName = "UserData\\" + this->UserName + " fileNumber.txt";
			std::string FileNamedAsUserName = "UserData\\" + this->UserName + ".txt";
			std::string FileNumberNewName = "UserData\\" + newName + " fileNumber.txt";
			std::string FileNamedAsUserNameNew = "UserData\\" + newName + ".txt";
			std::string ThemeOldName = "UserData\\" + this->UserName + " Theme.txt";
			std::string ThemeNewName = "UserData\\" + newName + " Theme.txt";
			// In Const Char* form
			const char* ThemeOldNameChar = ThemeOldName.c_str();
			const char* ThemeNewNameChar = ThemeNewName.c_str();
			const char* FileNumberOldNameChar = FileNumberOldName.c_str();
			const char* FileNumberNewNameChar = FileNumberNewName.c_str();
			const char* FileNamedAsUserNameChar = FileNamedAsUserName.c_str();
			const char* FileNamedAsUserNameNewChar = FileNamedAsUserNameNew.c_str();
			// Changes
			rename(FileNumberOldNameChar, FileNumberNewNameChar);
			rename(FileNamedAsUserNameChar, FileNamedAsUserNameNewChar);
			rename(ThemeOldNameChar, ThemeNewNameChar);
			std::cout << "Changes needs Restart to be applied";
			_getche();
			this->restart();
		}
		else if (dec == 'B')
		{
			break;
		}
	} while (1);
}
void A_Settings::changePassword()
{
	do {
		system("cls");
		std::cout << "Change Password\n\nUserName: " << this->UserName << std::endl;
		std::cout << "C. Change password\nB. Back";
		char dec = toupper(_getche());
		if (dec == 'C')
		{
			system("cls");
			std::string passwordOld;
			std::string passwordNew;
			std::cout << "Enter your old password: ";
			std::getline(std::cin, passwordOld);
			if (this->Password == passwordOld)
			{
				std::cout << "Enter your new Password: ";
				std::getline(std::cin, passwordNew);
				if (passwordNew.length() < 4) {
					system("cls");
					std::cout << "Password too short. Please Enter more than 4 characters\n";
					_getche();
					continue;
				}
				std::ifstream getPassword("./Users/Password.txt");
				std::string tmp, newFile = "";
				while (std::getline(getPassword, tmp))
				{
					if (tmp == this->Password)
						newFile += passwordNew + "\n";
					else
						newFile += tmp + "\n";
				}
				getPassword.close();
				std::ofstream savePassword("./Users/Password.txt");
				savePassword << newFile;
				savePassword.close();
				system("cls");
				std::cout << "Password Changed Successfully\nA Restart is reqiured";
				_getche();
				restart();
			}
			else
			{
				std::cout << "Password Does not match please try again";
				_getche();
				continue;
			}
		}
		else if(dec == 'B')
		{
			break;
		}
	} while (1);
}
void A_Settings::changePermission()
{
	std::string userChange;
	int usersLocation = 0;
	do {
		system("cls");
		std::cout << "Whose Permission do you want to change?\nNote: first user's permission can't be changed  Type :q to quit\n";
		for (unsigned i = 1; i <= this->AllUsers.size(); i++)
		{
			if (i == 1)
			{
				std::cout << i << ". " << AllUsers[i - 1] << "(Can't Change)\n";
			}
			else
			{
				std::cout << i << ". " << AllUsers[i - 1] << "\n";
			}
		}
		std::cout << "Type the userName" << std::endl << "=> ";
		std::getline(std::cin, userChange);
		if (userChange == ":q") {
			break;
		}
		if (userChange == this->AllUsers[0])
		{
			system("cls");
			std::cout << "Sorry can't change permission of the first user";
			_getch();
			break;
		}
		bool userDetected = false;
		for (unsigned i = 0; i < this->AllUsers.size(); i++)
		{
			if (this->AllUsers.at(i) == userChange) {
				usersLocation = i;
				userDetected = true;
				break;
			}
		}
		if (userDetected)
		{
			std::string userTag;
			system("cls");
			if (AllTags[usersLocation] == "N-Admin")
				userTag = "Non Admin";
			else
				userTag = "Admin";
			std::cout << "The user is currently " << userTag << std::endl;
			_getch();
			if (userTag == "Admin")
			{
				do {
					system("cls");
					std::cout << "Do you want to change " << this->AllUsers[usersLocation] << " to Non Admin (Y/N)\n";
					char dec = toupper(_getche());
					if (dec == 'Y')
					{
						system("cls");
						std::cout << "User's permission changed" << std::endl;
						std::ofstream theAllTagsFile("./Users/UserTag.txt");
						for (unsigned i = 0; i < this->AllTags.size(); i++)
						{
							if (i == usersLocation)
							{
								theAllTagsFile << "N-Admin\n";
							}
							else
							{
								theAllTagsFile << AllTags[i] << "\n";
							}
						}
						theAllTagsFile.close();
						LogError::setLog(this->UserName + " made " + AllUsers[usersLocation] + " Non-Admin");
						_getch();
						system("cls");
						std::cout << "This requires a restart";
						_getch();
						this->restart();
					}
					else if (dec == 'N')
					{
						system("cls");
						std::cout << "Nothing Changed!";
						_getch();
						break;
					}
					else
					{
						continue;
					}
				} while (1);
			}
			else
			{
				std::cout << "Do you want to change " << this->AllUsers[usersLocation]
					<< " to Admin (Y/N)\n";
				char dec = toupper(_getche());
				if (dec == 'Y')
				{
					system("cls");
					std::cout << "User's permission changed" << std::endl;
					std::ofstream theAllTagsFile("./Users/UserTag.txt");
					for (unsigned i = 0; i < this->AllTags.size(); i++)
					{
						if (i == usersLocation)
						{
							theAllTagsFile << "Admin\n";
						}
						else
						{
							theAllTagsFile << AllTags[i] << "\n";
						}
					}
					theAllTagsFile.close();
					LogError::setLog(this->UserName + " made " + AllUsers[usersLocation] + " Admin");
					_getch();
					system("cls");
					std::cout << "This requires a restart";
					_getch();
					this->restart();
				}
				else if (dec == 'N')
				{
					system("cls");
					std::cout << "Nothing Changed!";
					_getch();
					break;
				}
				else
				{
					continue;
				}
			}
			break;
		}
		else
		{
			system("cls");
			std::cout << "User Not Found";
			_getch();
			continue;
		}
	} while (1);
}
void A_Settings::addUser()
{
	do {
		system("cls");

		// Check if Maximum User Number has been reached
		if (AllUsers.size() >= 15) {
			std::cout << "Maximum User Number reached. Can't add more!";
			_getch();
			break;
		}

		// Asking for users permission
		std::cout << "Would you like to add a user(Y/N): ";
		char dec = toupper(_getche());

		// If User wants to add user
		if (dec == 'Y') {
			system("cls");
			std::string username_ask, password_ask;
			std::cout << "UserName: \n=>";
			std::getline(std::cin, username_ask);

			// If UserName already exists
			bool Found = false;
			for (auto& i : AllUsers) {
				if (i == username_ask) {
					std::cout << "\nSorry Username already exists\nPlease enter different username";
					_getch();
					Found = true;
				}
			}

			// To enter the name again
			if (Found) {
				break;
			}

			// Check if the name is valid
			if (username_ask.length() >= 40) {
				system("cls");
				std::cout << "The UserName is too long\nPlease enter again";
				_getch();
				break;
			}

			// Check if the name is valid #2
			for (auto& i : username_ask) {
				if (i == '\\' || i == '/' || i == '*' || i == '\"' || i == '|' || i == '?' || i == ':' || i == '<' || i == '>' || i == '(' || i == ')' || i == '&' || i == '^' || i == '%' || i == '$' || i == '#' || i == '@' || i == '!' || i == '+' || i == '=' || i == '{' || i == '}' || i == '[' || i == ']' || i == ';' || i == '\'' || i == '~' || i == '`' || i == '.' || i == ',')
				{
					system("cls");
					std::cout << "Sorry name contains special characters\nPlease enter the username again";
					_getche();
					break;
				}
			}

			// Ask For Password
			std::cout << "Password:\n=>";
			std::getline(std::cin, password_ask);

			// Check if the Password is valid
			if (password_ask.length() >= 40) {
				system("cls");
				std::cout << "The password is too long\nPlease enter it again";
				_getche();
				break;
			}
			else if (password_ask.length() < 4) {
				std::cout << "The Password is too short.\n Please enter at least 3 characters";
				_getche();
				break;
			}

			if (username_ask.length() < 3) {
				std::cout << "The Username is too short.\n Please enter at least 3 characters";
				_getche();
				break;
			}
			
			bool ProceedQ = true;

			// Show user the information they just entered and validate
			do {
				system("cls");
				std::cout << "The UserName: " << username_ask << "\nThe Password: " << password_ask << "\nProceed(Y/N)";
				char dec = toupper(_getche());

				// If proceed
				if (dec == 'Y') {
					system("cls");
					std::string mkdirText = "mkdir ";
					
					// Make files in UserData
					std::ofstream makeNametxt("./UserData/" + username_ask + ".txt");
					makeNametxt.close();
					std::ofstream makeNameFileNametxt("./UserData/" + username_ask + " fileNumber.txt");
					makeNameFileNametxt.close();
					std::ofstream makeThemetxt("./UserData/" + username_ask + " Theme.txt");
					makeThemetxt << 7 << "\n" << 0;
					makeThemetxt.close();

					std::string explorerName, explorerNamePassword;
					bool isSpace = false;
					// Checking For space in username
					for (auto& i : username_ask) {
						if (i == ' ') {
							explorerName = mkdirText + "Explorer\\\"" + username_ask + "\"\\Game";
							explorerNamePassword = mkdirText + "Explorer\\\"" + username_ask + "\"\\\"Password Saver\"";
							isSpace = true; 
							break;
						}
					}
					if (!isSpace) {
						explorerName = mkdirText + "Explorer\\" + username_ask + "\\Game";
						explorerNamePassword = mkdirText + "Explorer\\" + username_ask + "\\\"Password Saver\"";
					}

					// Make Files in Explorer
					system((explorerName.c_str()));
					system((explorerNamePassword).c_str());
					std::ofstream makeEAF("./Explorer/" + username_ask + "/Game/EAF.txt");
					makeEAF << 0;
					makeEAF.close();
					std::ofstream makeSnake("./Explorer/" + username_ask + "/Game/Snake.txt");
					makeSnake << 0;
					makeSnake.close();
					std::ofstream makeGuess("./Explorer/" + username_ask + "/Game/Guess.txt");
					makeGuess << 9999;
					makeGuess.close();
					std::ofstream makePassword("./Explorer/" + username_ask + "/Password Saver/password.txt");
					makePassword.close();

					// Set all the password, userlist files
					std::ofstream addUser("./Users/UserList.txt", std::ios::app);
					addUser << username_ask << "\n";
					addUser.close();
					std::ofstream addPassword("./Users/Password.txt", std::ios::app);
					addPassword << password_ask << "\n";
					addPassword.close();
					std::ofstream addTag("./Users/UserTag.txt", std::ios::app);
					addTag << "N-Admin\n";
					addTag.close();

					LogError::setLog(this->UserName + " added new user named " + username_ask);

					// Done and now restart
					system("cls");
					std::cout << "User Created!!\nRestart is required!";
					_getch();
					this->restart();
				}
				// If not proceed
				else if (dec == 'N') {
					system("cls");
					std::cout << "Taking back you to the menu!";
					_getch();
					ProceedQ = false;
					break;
				}
				else {
					continue;
				}
			} while (1);

			// If rejected, go to the menu
			if (!ProceedQ) {
				break;
			}
		}
		// If User doesnot want to add user
		else if (dec == 'N') {
			system("cls");
			std::cout << "Nothing changed!";
			_getch();
			break;
		}
		else {
			continue;
		}
	} while (1);
}
void A_Settings::removeUser()
{
	std::string username_ask, password_ask;
	do {
		system("cls");

		// Printing all the users
		std::cout << "Which user is being removed? (First User can't be removed)\nType :q to go back!\n";
		for (unsigned i = 1; i <= this->AllUsers.size(); i++)
		{
			if (i == 1)
			{
				std::cout << i << ". " << AllUsers[i - 1] << "(Can't remove)\n";
			}
			else
			{
				std::cout << i << ". " << AllUsers[i - 1] << "\n";
			}
		}

		// Asking the username
		std::cout << "Type the Username: ";
		std::getline(std::cin, username_ask);

		if (username_ask == ":q") {
			system("cls");
			std::cout << "Nothing changed!!";
			_getche();
			break;
		}

		// Checking if the request is valid or not
		if (username_ask == AllUsers[0]) {
			system("cls");
			std::cout << "You can not remove first user";
			_getch();
			break;
		}

		// Checking if the request is valid or not #2
		bool userFound = false;
		for (unsigned i = 1; i < AllUsers.size(); i++) {
			if (AllUsers[i] == username_ask) {
				userFound = true;
				break;
			}
		}
		if (!userFound) {
			system("cls");
			std::cout << "User Does not exist";
			_getch();
			break;
		}

		// Validation passed & asking for password
		std::cout << "Type YOUR password: ";
		std::getline(std::cin, password_ask);

		// Validating Password
		if (password_ask != this->Password) {
			system("cls");
			std::cout << "Password is incorrect!\nTry again!";
			_getch();
			break;
		}

		// Confirming the removal of the user
		do {
			system("cls");
			std::cout << "Are you sure you want to remove the user, All Data will be lost!!";
			char dec = toupper(_getche());

			// All Validation passed & removing user Process
			if (dec == 'Y') {

				// removing everything from Userdata
				std::string removeNametxt, removeNameFilenumbertxt, removeThemetxt, removeFromExplorer;
				bool containsSpace = false;
				for (unsigned i = 0; i < username_ask.length(); i++)
				{
					if (username_ask[i] == ' ') {
						containsSpace = true;
						removeNametxt = "UserData\\" + username_ask + ".txt";
						removeNameFilenumbertxt = "UserData\\" + username_ask + " fileNumber.txt";
						removeThemetxt = "UserData\\" + username_ask + " Theme.txt";
						removeFromExplorer = "rmdir Explorer\\\"" + username_ask + "\" /Q /S";
						break;
					}
				}
				if (!containsSpace) {
					removeNametxt = "UserData\\" + username_ask + ".txt";
					removeNameFilenumbertxt = "UserData\\" + username_ask + " fileNumber.txt";
					removeThemetxt = "UserData\\" + username_ask + " Theme.txt";
					removeFromExplorer = "rmdir Explorer\\" + username_ask + " /Q /S";
				}

				remove(removeNametxt.c_str());
				remove(removeThemetxt.c_str());
				remove(removeNameFilenumbertxt.c_str());
				system(removeFromExplorer.c_str());

				// remove From Users
				int userNumber = 0;
				std::ofstream modifyUserList("./Users/UserList.txt");
				for (unsigned i = 0; i < this->AllUsers.size(); i++)
				{
					if (AllUsers[i] != username_ask) {
						modifyUserList << AllUsers[i] << "\n";
					}
					else
					{
						userNumber = i;
					}
				}
				modifyUserList.close();
				std::ofstream modifyPassword("./Users/Password.txt");
				for (unsigned i = 0; i < this->AllPasswords.size(); i++)
				{
					if (i != userNumber) {
						modifyPassword << AllPasswords[i] << "\n";
					}
				}
				modifyPassword.close();
				std::ofstream modifyTag("./Users/UserTag.txt");
				for (unsigned i = 0; i < this->AllTags.size(); i++)
				{
					if (i != userNumber) {
						modifyTag << AllTags[i] << "\n";
					}
				}
				modifyTag.close();

				LogError::setLog(this->UserName + " removed user named " + username_ask);

				// Finsihed restart
				system("cls");
				std::cout << "Removed user!\nRestart required!";
				_getch();
				this->restart();
			}
			// Didnot confirm
			else if (dec == 'N') {
				system("cls");
				std::cout << "User Not removed";
				_getch();
				break;
			}
			else {
				continue;
			}
		} while (1);

	} while (1);
}
// Restart
void A_Settings::restart()
{
	system("cls");
	std::string RestartString = "Restarting......";
	for (unsigned i = 0; i < RestartString.length(); i++) {
		std::cout << RestartString.at(i);
		this->colorShifter();
	}
	std::string  restartText = "start ";
	bool isSpaceDetected = false;
	unsigned positionOfBS = 0;
	char openExe[MAX_PATH];
	DWORD size = GetModuleFileNameA(NULL, openExe, MAX_PATH);
	for (int i = 0; i < MAX_PATH; i++)
	{
		if (openExe[i] == NULL)
			break;
		else if (openExe[i] == '\\' && isSpaceDetected) {
			positionOfBS = i + 1;
			restartText += "\"";
			restartText += openExe[i];
			isSpaceDetected = false;
		}
		else if (openExe[i] == '\\' && !isSpaceDetected) {
			positionOfBS = i + 1;
			restartText += openExe[i];
		}
		else if (openExe[i] == ' ') {
			restartText += openExe[i];
			if (!isSpaceDetected) {
				isSpaceDetected = true;
				restartText.insert(positionOfBS + 6, "\"");
			}
		}
		else {
			restartText += openExe[i];
		}
	}
	LogError::setLog(this->UserName + " restarted the PC");
	system((restartText).c_str());
	exit(0);
}
void A_Settings::colorShifter()
{
	int color = rand() % 7;
	switch (color) {
	case 0:
		system("color 7");
		break;
	case 1:
		system("color 1");
		break;
	case 2:
		system("color 2");
		break;
	case 3:
		system("color 3");
		break;
	case 4:
		system("color 4");
		break;
	case 5:
		system("color 5");
		break;
	case 6:
		system("color 6");
		break;
	}
}
// Settings inside Theme Settings
void A_Settings::foreground()
{
	std::string pathOfTheThemeFile = "./UserData/" + this->UserName + " Theme.txt";
	std::string backGroundColor, foreGroundColor;
	do {
		system("cls");
		// Importing the BackGround Color
		std::ifstream importcolor(pathOfTheThemeFile);
		importcolor >> foreGroundColor;
		importcolor >> backGroundColor;
		importcolor.close();
		std::cout << "1. White\n2. Bright White\n3. Grey\n4. Yellow\n5. Green\n6. Blue\n7. red\n8. Black\nB. Back";
		char dec = toupper(_getch());
		system("cls");
		if (dec == '1') {
			if (backGroundColor != "7" && backGroundColor != "F") {
				std::string newText = "color " + backGroundColor + "7";
				system(newText.c_str());
				std::cout << "Color set!";
				foreGroundColor = "7";
				_getche();
				break;
			}
			else {
				std::cout << "The BackGround Color and foreGround Color are same. Please choose different color";
				_getche();
				continue;
			}
		}
		else if (dec == '2') {
			if (backGroundColor != "7" && backGroundColor != "F") {
				std::string newText = "color " + backGroundColor + "F";
				system(newText.c_str());
				std::cout << "Color set!";
				foreGroundColor = "F";
				_getche();
				break;
			}
			else {
				std::cout << "The BackGround Color and foreGround Color are same. Please choose different color";
				_getche();
				continue;
			}
		}
		else if (dec == '3') {
			if (backGroundColor != "8") {
				std::string newText = "color " + backGroundColor + "8";
				system(newText.c_str());
				std::cout << "Color set!";
				foreGroundColor = "8";
				_getche();
				break;
			}
			else {
				std::cout << "The BackGround Color and foreGround Color are same. Please choose different color";
				_getche();
				continue;
			}
		}
		else if (dec == '4') {
			if (backGroundColor != "6") {
				std::string newText = "color " + backGroundColor + "6";
				system(newText.c_str());
				std::cout << "Color set!";
				foreGroundColor = "6";
				_getche();
				break;
			}
			else {
				std::cout << "The BackGround Color and foreGround Color are same. Please choose different color";
				_getche();
				continue;
			}
		}
		else if (dec == '5') {
			if (backGroundColor != "2") {
				std::string newText = "color " + backGroundColor + "2";
				system(newText.c_str());
				std::cout << "Color set!";
				foreGroundColor = "2";
				_getche();
				break;
			}
			else {
				std::cout << "The BackGround Color and foreGround Color are same. Please choose different color";
				_getche();
				continue;
			}
		}
		else if (dec == '6') {
			if (backGroundColor != "1") {
				std::string newText = "color " + backGroundColor + "1";
				system(newText.c_str());
				std::cout << "Color set!";
				foreGroundColor = "1";
				_getche();
				break;
			}
			else {
				std::cout << "The BackGround Color and foreGround Color are same. Please choose different color";
				_getche();
				continue;
			}
		}
		else if (dec == '7') {
			if (backGroundColor != "4") {
				std::string newText = "color " + backGroundColor + "4";
				system(newText.c_str());
				std::cout << "Color set!";
				foreGroundColor = "4";
				_getche();
				break;
			}
			else {
				std::cout << "The BackGround Color and foreGround Color are same. Please choose different color";
				_getche();
				continue;
			}
		}
		else if (dec == '8') {
			if (backGroundColor != "0") {
				std::string newText = "color " + backGroundColor + "0";
				system(newText.c_str());
				std::cout << "Color set!";
				foreGroundColor = "0";
				_getche();
				break;
			}
			else {
				std::cout << "The BackGround Color and foreGround Color are same. Please choose different color";
				_getche();
				continue;
			}
		}
		else if (dec == 'B') {
			break;
		}
		else {
			continue;
		}
 	} while (1);
	std::ofstream saveTheme(pathOfTheThemeFile);
	saveTheme << foreGroundColor << "\n" << backGroundColor;
	saveTheme.close();
}
void A_Settings::background()
{
	std::string pathOfTheThemeFile = "./UserData/" + this->UserName + " Theme.txt";
	std::string backGroundColor, foreGroundColor;
	do {
		system("cls");
		// Importing the BackGround Color
		std::ifstream importcolor(pathOfTheThemeFile);
		importcolor >> foreGroundColor;
		importcolor >> backGroundColor;
		importcolor.close();
		std::cout << "1. White\n2. Bright White\n3. Grey\n4. Yellow\n5. Green\n6. Blue\n7. red\n8. Black\nB. Back";
		char dec = toupper(_getch());
		system("cls");
		if (dec == '1') {
			if (foreGroundColor != "7" && foreGroundColor != "F") {
				std::string newText = "color 7" + foreGroundColor;
				system(newText.c_str());
				std::cout << "Color set!";
				backGroundColor = "7";
				_getche();
				break;
			}
			else {
				std::cout << "The BackGround Color and foreGround Color are same. Please choose different color";
				_getche();
				continue;
			}
		}
		else if (dec == '2') {
			if (foreGroundColor != "7" && foreGroundColor != "F") {
				std::string newText = "color F" + foreGroundColor;
				system(newText.c_str());
				std::cout << "Color set!";
				backGroundColor = "F";
				_getche();
				break;
			}
			else {
				std::cout << "The BackGround Color and foreGround Color are same. Please choose different color";
				_getche();
				continue;
			}
		}
		else if (dec == '3') {
			if (foreGroundColor != "8") {
				std::string newText = "color 8" + foreGroundColor;
				system(newText.c_str());
				std::cout << "Color set!";
				backGroundColor = "8";
				_getche();
				break;
			}
			else {
				std::cout << "The BackGround Color and foreGround Color are same. Please choose different color";
				_getche();
				continue;
			}
		}
		else if (dec == '4') {
			if (foreGroundColor != "6") {
				std::string newText = "color 6" + foreGroundColor;
				system(newText.c_str());
				std::cout << "Color set!";
				backGroundColor = "6";
				_getche();
				break;
			}
			else {
				std::cout << "The BackGround Color and foreGround Color are same. Please choose different color";
				_getche();
				continue;
			}
		}
		else if (dec == '5') {
			if (foreGroundColor != "2") {
				std::string newText = "color 2" + foreGroundColor;
				system(newText.c_str());
				std::cout << "Color set!";
				backGroundColor = "2";
				_getche();
				break;
			}
			else {
				std::cout << "The BackGround Color and foreGround Color are same. Please choose different color";
				_getche();
				continue;
			}
		}
		else if (dec == '6') {
			if (foreGroundColor != "1") {
				std::string newText = "color 1" + foreGroundColor;
				system(newText.c_str());
				std::cout << "Color set!";
				backGroundColor = "1";
				_getche();
				break;
			}
			else {
				std::cout << "The BackGround Color and foreGround Color are same. Please choose different color";
				_getche();
				continue;
			}
		}
		else if (dec == '7') {
			if (foreGroundColor != "4") {
				std::string newText = "color 4" + foreGroundColor;
				system(newText.c_str());
				std::cout << "Color set!";
				backGroundColor = "4";
				_getche();
				break;
			}
			else {
				std::cout << "The BackGround Color and foreGround Color are same. Please choose different color";
				_getche();
				continue;
			}
		}
		else if (dec == '8') {
			if (foreGroundColor != "0") {
				std::string newText = "color 0" + foreGroundColor;
				system(newText.c_str());
				std::cout << "Color set!";
				backGroundColor = "0";
				_getche();
				break;
			}
			else {
				std::cout << "The BackGround Color and foreGround Color are same. Please choose different color";
				_getche();
				continue;
			}
		}
		else if (dec == 'B') {
			break;
		}
		else {
			continue;
		}
 	} while (1);
	std::ofstream saveBGColor(pathOfTheThemeFile);
	saveBGColor << foreGroundColor << "\n" << backGroundColor;
	saveBGColor.close();
}
void A_Settings::schemes()
{
	std::string pathOfTheThemeFile = "./UserData/" + this->UserName + " Theme.txt";
	bool changed = true;
	std::string backGroundColor, foreGroundColor;
	do {
		system("cls");
		std::cout << "1. Light theme\n2. Dark Theme\n3. Hacker\nB. Back";
		char dec = toupper(_getche());
		if (dec == '1') {
			system("color F0");
			backGroundColor = "F";
			foreGroundColor = "0";
			system("cls");
			std::cout << "Changed Theme!!";
			_getche();
			break;
		}
		else if (dec == '2') {
			system("color 0F");
			backGroundColor = "0";
			foreGroundColor = "F";
			system("cls");
			std::cout << "Changed Theme!!";
			_getche();
			break;
		}
		else if (dec == '3') {
			backGroundColor = "0";
			foreGroundColor = "2";
			system("color 02");
			system("cls");
			std::cout << "Changed Theme!!";
			_getche();
			break;
		}
		else if (dec == 'B') {
			changed = false;
			break;
		}
		else {
			changed = false;
			continue;
		}
	} while (1);
	if (changed) {
		std::ofstream openText(pathOfTheThemeFile);
		openText << foreGroundColor << "\n" << backGroundColor;
		openText.close();
	}
}
// Settings inside Computer Settings
void A_Settings::resetComputer()
{
	do {
		system("cls");
		std::cout << "Do you really want to continue?\nThis will reset the computer and remove all the users except the main user(Y/N)\n";
		char dec = toupper(_getch());
		if (dec == 'Y') {
			std::string checkPassword;
			system("cls");
			std::cout << "Enter the password\n=>";
			std::getline(std::cin, checkPassword);
			if (checkPassword == this->Password) {
				// Removing all The users
				for (unsigned i = 0; i < this->AllUsers.size(); i++)
				{
					this->removeASpecificUser(AllUsers[i]);
				}
				// Adding the initial User
				this->makeASpecificUser("Admin", "Admin", "Admin");
				LogError::setLog(this->UserName + " reseted the PC");
				IfReseted::changeValue(true);
				std::cout << "Reseted!!!\nRestarting Pc";
				Sleep(1000);
				this->restart();
				break;
			}
			else {
				std::cout << "Password is incorrect";
				_getche();
				break;
			}
		}
		else if (dec == 'N') {
			std::cout << "Nothing Changed!!";
			_getche();
			break;
		}
		else {
			continue;
		}
	} while (1);
}
void A_Settings::formatDisk()
{
	do {
		system("cls");
		std::cout << "Do you really want to continue?\nThis will erase all the data of all the users(Y/N)\n";
		char dec = toupper(_getch());
		if (dec == 'Y') {
			std::string checkPassword;
			system("cls");
			std::cout << "Enter the password\n=>";
			std::getline(std::cin, checkPassword);
			if (checkPassword == this->Password) {
				for (unsigned i = 0; i < AllUsers.size(); i++)
				{
					this->formatASpecificData(AllUsers[i]);
				}
				LogError::setLog(this->UserName + " formatted the main disk");
				std::cout << "Formatted PC\nRestarting PC";
				Sleep(1000);
				this->restart();
			}
			else {
				std::cout << "Password is incorrect";
				_getche();
				break;
			}
		}
		else if (dec == 'N') {
			std::cout << "Nothing Changed!!";
			_getche();
			break;
		}
		else {
			continue;
		}
	} while (1);
}
void A_Settings::removeAllUsers()
{
	do {
		system("cls");
		std::cout << "Do you really want to continue?\nThis will remove all the users except the first user(Y/N)\n";
		char dec = toupper(_getch());
		if (dec == 'Y') {
			std::string checkPassword;
			system("cls");
			std::cout << "Enter the password\n=>";
			std::getline(std::cin, checkPassword);
			if (checkPassword == this->Password) {
				std::vector<std::string> copyOfAllUser = AllUsers;
				for (unsigned i = 1; i < copyOfAllUser.size(); i++)
				{
					this->removeASpecificUser(copyOfAllUser[i]);
				}
				LogError::setLog(this->UserName + " removed all the users");
				std::cout << "Removed all the Users!!\nRestarting PC";
				Sleep(1000);
				restart();
			}
			else {
				std::cout << "Password is incorrect";
				_getche();
				break;
			}
		}
		else if (dec == 'N') {
			std::cout << "Nothing Changed!!";
			_getche();
			break;
		}
		else {
			continue;
		}
	} while (1);
}
void A_Settings::makeAllUsersNonAdmin()
{
	do {
		system("cls");
		std::cout << "Do you really want to continue?\nThis will make all the users non Admin(Y/N)\n";
		char dec = toupper(_getch());
		if (dec == 'Y') {
			std::string checkPassword;
			system("cls");
			std::cout << "Enter the password\n=>";
			std::getline(std::cin, checkPassword);
			if (checkPassword == this->Password) {
				std::ofstream setAllTags("./Users/Usertag.txt");
				setAllTags << "Admin\n";
				for (unsigned i = 1; i < this->AllTags.size(); i++) {
					setAllTags << "N-Admin\n";
				}
				setAllTags.close();
				LogError::setLog(this->UserName + " made everyone N-Admin");
				std::cout << "All users are now Non-Admin\nRestarting Computer";
				Sleep(1000);
				this->restart();
			}
			else {
				std::cout << "Password is incorrect";
				_getche();
				break;
			}
		}
		else if (dec == 'N') {
			std::cout << "Nothing Changed!!";
			_getche();
			break;
		}
		else {
			continue;
		}
	} while (1);
}
void A_Settings::removeLog()
{
	do {
		system("cls");
		std::cout << "Do you really want to continue?\nThis will erase all the data in the log file(Y/N)\n";
		char dec = toupper(_getch());
		if (dec == 'Y') {
			std::string checkPassword;
			system("cls");
			std::cout << "Enter the password\n=>";
			std::getline(std::cin, checkPassword);
			if (checkPassword == this->Password) {
				std::ofstream openLogFile("./Log/Log.dat");
				openLogFile << "";
				openLogFile.close();
				std::cout << "Log Removed!!";
				LogError::setLog(this->UserName + " reseted the Log File");
				_getche();
				break;
			}
			else {
				std::cout << "Password is incorrect";
				_getche();
				break;
			}
		}
		else if (dec == 'N') {
			std::cout << "Nothing Changed!!";
			_getche();
			break;
		}
		else {
			continue;
		}
	} while (1);
}

// Fast Use
void A_Settings::removeASpecificUser(std::string& name)
{
	// removing everything from Userdata
	std::string removeNametxt, removeNameFilenumbertxt, removeThemetxt, removeFromExplorer;
	bool containsSpace = false;
	for (unsigned i = 0; i < name.length(); i++)
	{
		if (name[i] == ' ') {
			containsSpace = true;
			removeNametxt = "UserData\\" + name + ".txt";
			removeNameFilenumbertxt = "UserData\\" + name + " fileNumber.txt";
			removeThemetxt = "UserData\\" + name + " Theme.txt";
			removeFromExplorer = "rmdir Explorer\\\"" + name + "\" /Q /S";
			break;
		}
	}
	if (!containsSpace) {
		removeNametxt = "UserData\\" + name + ".txt";
		removeNameFilenumbertxt = "UserData\\" + name + " fileNumber.txt";
		removeThemetxt = "UserData\\" + name + " Theme.txt";
		removeFromExplorer = "rmdir Explorer\\" + name + " /Q /S";
	}

	remove(removeNametxt.c_str());
	remove(removeThemetxt.c_str());
	remove(removeNameFilenumbertxt.c_str());
	system(removeFromExplorer.c_str());

	// remove From Users
	int userNumber = 0;
	std::ofstream modifyUserList("./Users/UserList.txt");
	for (unsigned i = 0; i < this->AllUsers.size(); i++)
	{
		if (AllUsers[i] != name) {
			modifyUserList << AllUsers[i] << "\n";
		}
		else
		{
			userNumber = i;
			AllUsers.erase(AllUsers.begin() + i, AllUsers.begin() + i + 1);
			i--;
		}
	}
	modifyUserList.close();
	std::ofstream modifyPassword("./Users/Password.txt");
	for (unsigned i = 0; i < this->AllPasswords.size(); i++)
	{
		if (i != userNumber) {
			modifyPassword << AllPasswords[i] << "\n";
		}
		else
		{
			AllPasswords.erase(AllPasswords.begin() + i, AllPasswords.begin() + i + 1);
		}
	}
	modifyPassword.close();
	std::ofstream modifyTag("./Users/UserTag.txt");
	for (unsigned i = 0; i < this->AllTags.size(); i++)
	{
		if (i != userNumber) {
			modifyTag << AllTags[i] << "\n";
		}
		else
		{
			AllTags.erase(AllTags.begin() + i, AllTags.begin() + i + 1);
		}
	}
	modifyTag.close();
}
void A_Settings::formatASpecificData(std::string& name)
{
	std::string resetNametxt, resetNameFilenumbertxt, resetThemetxt, resetFromExplorer;
	bool containsSpace = false;
	for (unsigned i = 0; i < name.length(); i++)
	{
		if (name[i] == ' ') {
			containsSpace = true;
			resetNametxt = "UserData\\" + name + ".txt";
			resetNameFilenumbertxt = "UserData\\" + name + " fileNumber.txt";
			resetThemetxt = "UserData\\" + name + " Theme.txt";
			resetFromExplorer = "rmdir Explorer\\\"" + name + "\" /Q /S";
			break;
		}
	}
	if (!containsSpace) {
		resetNametxt = "UserData\\" + name + ".txt";
		resetNameFilenumbertxt = "UserData\\" + name + " fileNumber.txt";
		resetThemetxt = "UserData\\" + name + " Theme.txt";
		resetFromExplorer = "rmdir Explorer\\" + name + " /Q /S";
	}
	std::ofstream nametxt(resetNametxt);
	nametxt << "";
	nametxt.close();

	std::ofstream nameFileNumbertxt(resetNameFilenumbertxt);
	nameFileNumbertxt << "";
	nameFileNumbertxt.close();

	std::ofstream themetxt(resetThemetxt);
	themetxt << "7\n0";
	themetxt.close();

	system(resetFromExplorer.c_str());

	// Make Empty Files
	std::string explorerName, explorerNamePassword;
	std::string mkdirText = "mkdir ";

	bool isSpace = false;
	for (auto& i : name) {
		if (i == ' ') {
			explorerName = mkdirText + "Explorer\\\"" + name + "\"\\Game";
			explorerNamePassword = mkdirText + "Explorer\\\"" + name + "\"\\\"Password Saver\"";
			isSpace = true;
			break;
		}
	}
	if (!isSpace) {
		explorerName = mkdirText + "Explorer\\" + name + "\\Game";
		explorerNamePassword = mkdirText + "Explorer\\" + name + "\\\"Password Saver\"";
	}

	// Make Files in Explorer
	system((explorerName.c_str()));
	system((explorerNamePassword).c_str());
}
void A_Settings::makeASpecificUser(std::string name, std::string password, std::string tag)
{
	std::string mkdirText = "mkdir ";

	// Make files in UserData
	std::ofstream makeNametxt("./UserData/" + name + ".txt");
	makeNametxt.close();
	std::ofstream makeNameFileNametxt("./UserData/" + name + " fileNumber.txt");
	makeNameFileNametxt.close();
	std::ofstream makeThemetxt("./UserData/" + name + " Theme.txt");
	makeThemetxt << 7 << "\n" << 0;
	makeThemetxt.close();

	std::string explorerName, explorerNamePassword;
	bool isSpace = false;
	// Checking For space in username
	for (auto& i : name) {
		if (i == ' ') {
			explorerName = mkdirText + "Explorer\\\"" + name + "\"\\Game";
			explorerNamePassword = mkdirText + "Explorer\\\"" + name + "\"\\\"Password Saver\"";
			isSpace = true;
			break;
		}
	}
	if (!isSpace) {
		explorerName = mkdirText + "Explorer\\" + name + "\\Game";
		explorerNamePassword = mkdirText + "Explorer\\" + name + "\\\"Password Saver\"";
	}

	// Make Files in Explorer
	system((explorerName.c_str()));
	system((explorerNamePassword).c_str());
	std::ofstream makeEAF("./Explorer/" + name + "/Game/EAF.txt");
	makeEAF << 0;
	makeEAF.close();
	std::ofstream makeSnake("./Explorer/" + name + "/Game/Snake.txt");
	makeSnake << 0;
	makeSnake.close();
	std::ofstream makeGuess("./Explorer/" + name + "/Game/Guess.txt");
	makeGuess << 9999;
	makeGuess.close();
	std::ofstream makePassword("./Explorer/" + name + "/Password Saver/password.txt");
	makePassword.close();

	// Set all the password, userlist files
	std::ofstream addUser("./Users/UserList.txt");
	addUser << name << "\n";
	addUser.close();
	std::ofstream addPassword("./Users/Password.txt");
	addPassword << password << "\n";
	addPassword.close();
	std::ofstream addTag("./Users/UserTag.txt");
	addTag << tag << "\n";
	addTag.close();
}