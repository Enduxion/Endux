#include "pch.h"
#include "Applications.h"
//Functions
void Applications::AppMainMenu()
{
	bool loop;
	do {
		loop = true;
		system("cls");
		std::cout << "----------------------\n";
		std::cout << "C. Calculator\nE. Explorer\nT. Text editor\nP. Password Saver\nD. Date and time\nS. Snake Game\nF. Eat and Feed\nO. Tic Tac Toe\nB. Back\n";
		std::cout << "----------------------\n";
		char dec = _getche();
		dec = toupper(dec);
		std::cout << dec;
		switch (dec) {
		case 'C':
			this->App_Calulator();
			break;
		case 'E':
			this->App_Explorer();
			break;
		case 'T':
			this->App_TextEditor();
			break;
		case 'P':
			this->App_PasswordSaver();
			break;
		case 'D':
			this->App_DateAndTime();
			break;
		case 'S':
			this->game = new Game(this->currentUser, this->currentStat, "Snake");
			delete this->game;
			break;
		case 'F':
			this->game = new Game(this->currentUser, this->currentStat, "EAF");
			delete this->game;
			break;
		case 'O':
			this->game = new Game(this->currentUser, this->currentStat, "TTT");
			delete this->game;
			break;
		case 'B':
			loop = false;
			break;
		}
	} while (loop);
}
void Applications::Cls()
{
	COORD CO;
	CO.X = 0;
	CO.Y = 0;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), CO);
}
//Applications
//Explorer
void Applications::App_Explorer()
{
	do {
		system("cls");
		std::cout << "------------------\n|    Explorer    |\n------------------\n";
		std::string FileLocation = "./UserData/" + this->currentUser + " fileNumber.txt"; // ./UserData/Pawan Gurung fileNumber.txt
		std::string DisplayString = "";
		std::string DisplayStringAfter = "";
		std::ifstream allFileDisplay(FileLocation); // FileNumber
		while (getline(allFileDisplay, DisplayString)) //Getting all the file number in DisplayString
		{
			std::cout << DisplayString << "\n"; //Printing on the console
		}
		std::cout << "/. Back\n\n\nPress 'D' inside file to delete the file";
		allFileDisplay.close();
		char dec = _getche();
		if (dec == '/')
		{
			break;
		}
		bool FileFound = false;
		std::ifstream FileallFileDisplay(FileLocation); //fileNumber
		while (getline(FileallFileDisplay, DisplayString)) //DisplayString has all value again
		{
			if (dec == DisplayString[0]) //Checking if the first letter match with dec
			{
				FileFound = true; //File Found 
				DisplayStringAfter = DisplayString.substr(3, DisplayString.length()); // DisplayAfter does not contain (a.)
				break;
			}
		}
		FileallFileDisplay.close();
		if (FileFound) //If They match up
		{
			system("cls");
			std::string TextDisplay = "";
			std::string openedFile = "./Explorer/" + this->currentUser + "/" + DisplayStringAfter + ".txt"; //That file you want to open
			std::ifstream FileDisplayFormExplorer(openedFile); // File you opened is now opened
			while (getline(FileDisplayFormExplorer, TextDisplay)) //TextDisplay has all your file data
			{
				std::cout << TextDisplay << "\n"; //printing to the console
			}
			FileDisplayFormExplorer.close(); 
			char dec2 = _getche(); //delete or not
			if (dec2 == 'D' || dec2 == 'd') //If delete
			{
				system("cls");
				std::cout << "Do you want to delete the file? Y/N"; //confirmation
				char dec3 = toupper(_getche());
				if (dec3 == 'Y') //If confirmed
				{
					std::ofstream SaveTheNumberFile("./Explorer/temp.txt", std::ios::app);
					SaveTheNumberFile << "";
					SaveTheNumberFile.close();
					std::string deleteTheFile = ""; 
					std::string FileAfterDeleting = "";
					std::string deleteTheFileAfter;
					bool deleted = false;
					std::ofstream SaveTheNumber1File("./Explorer/temp.txt");
					SaveTheNumber1File << "";
					SaveTheNumber1File.close();
					std::ifstream FileDelete(FileLocation); //File Number
					while (getline(FileDelete, deleteTheFile)) //deleteTheFile contains info from the data file
					{
						deleteTheFileAfter = deleteTheFile.substr(3, deleteTheFile.length());
						if (DisplayString != deleteTheFile) //the initial file with (a.) == Second initial File with (a. )
						{
							std::ofstream SaveTheNumberFile("./Explorer/temp.txt",std::ios::app);
							SaveTheNumberFile << deleteTheFileAfter << "\n";
							SaveTheNumberFile.close();
						}
					}
					FileDelete.close();
					std::ofstream ExportTheFile1(FileLocation);
					ExportTheFile1 << "";
					ExportTheFile1.close();
					std::string importLast = "";
					std::ifstream ImportTheFile("./Explorer/temp.txt");
					char value = 'a';
					while (getline(ImportTheFile, importLast))
					{
						std::ofstream ExportTheFile(FileLocation, std::ios::app);
						ExportTheFile << value << ". " << importLast << "\n";
						ExportTheFile.close();
						++value;
					}
					ImportTheFile.close();
					remove(openedFile.c_str());
				}
			}
		}
	} while (1);
}
//Text Editor
void Applications::App_TextEditor()
{
	do {
		system("cls");
		std::cout << "N. New File\nB. Back";
		char dec = toupper(_getche());
		std::string TypedText, tempText;
		if (dec == 'N') {
			system("cls");
			while (getline(std::cin, tempText) && tempText != ":wq" && tempText != ":q")
			{
				TypedText += tempText + "\n";
			}
			if (tempText == ":wq")
			{
				bool invalidChar = false;
				while (1)
				{
					bool invalidChar = false;
					std::string FileName;
					std::cout << "Enter the name of the file: ";
					getline(std::cin, FileName);
					if (FileName.length() >= 256) {
						std::cout << "File Name too long. Please Enter the file name again";
						FileName.clear();
						_getche();
						continue;
					}
					else if (FileName.length() == 0) {
						std::cout << "File Name too Short. Please Enter the file name again";
						FileName.clear();
						_getche();
						continue;
					}
					for (unsigned i = 0; i < FileName.length(); i++) {
						if (FileName[i] == '\\' || FileName[i] == '/' || FileName[i] == '*' || FileName[i] == '\"' || FileName[i] == '|' || FileName[i] == '?' || FileName[i] == ':' || FileName[i] == '<' || FileName[i] == '>')
						{
							std::cout << "File Name contains invalid characters. Please Enter the file name again";
							system("cls");
							FileName.clear();
							_getche();
							invalidChar = true;
							break;
						}
					}
					if (invalidChar)
						continue;
					std::string checkFile = "./UserData/" + this->currentUser + " fileNumber.txt";
					std::string tempCheck;
					std::ifstream fileExist(checkFile);
					while (getline(fileExist, tempCheck))
					{
						tempCheck = tempCheck.substr(3, tempCheck.length());
						if (tempCheck == FileName)
						{
							system("cls");
							std::cout << "File already exists, please choose a different filename.";
							FileName.clear();
							invalidChar = true;
							_getche();
							break;
						}
					}
					if (invalidChar)
						continue;
					std::string currentDir = "./Explorer/" + this->currentUser + "/" + FileName + ".txt"; //./Explorer/Pawan Gurung/File1.txt
					std::string FileNumber = "./UserData/" + this->currentUser + " fileNumber.txt"; //./UserData/Pawan Gurung fileNumber.txt
					std::string FileFrontNumber = ""; 
					char ofAtoZ = '1';
					std::ifstream getFileNumber(FileNumber); // ./UserData/Pawan Gurung fileNumber.txt
					while (getline(getFileNumber, FileFrontNumber))
					{
						ofAtoZ = FileFrontNumber[0];
					}
					getFileNumber.close(); //closed
					std::ofstream saveFileName(FileNumber, std::ios::app);
					if (ofAtoZ == '1') {
						saveFileName << "a. " << FileName << "\n";
					}
					else if (ofAtoZ == 'z')
					{
						std::cout << "File too populated. delete some file before saving this file";
						_getche();
						invalidChar = true;
						break;
					}
					else
					{
						++ofAtoZ;
						saveFileName << ofAtoZ << ". " << FileName << "\n";
					}
					saveFileName.close();
					std::ofstream DIR(currentDir); //./Explorer/Pawan Gurung/File1.txt
					DIR << TypedText; //Saaving Text in file
					DIR.close(); //
					std::cout << "File Saved SuccessFully";
					_getche();
					break;
				}
				if (invalidChar)
					continue;
			}
			else if (tempText == ":q")
			{
				TypedText = "";
				std::cout << "File Not Saved";
				_getche();
				break;
			}
		}
		else if (dec == 'B')
		{
			break;
		}
	} while (1);
}
//Password 2.0 Files
bool Applications::emailCheck(std::string email)
{
	int adLoc = 0;
	for (unsigned i = 0; i < email.length(); i++) {
		if (email[i] == '@') {
			adLoc = i;
		}
		if (email[i] == ' ') {
			return false;
		}
	}
	if (adLoc == 0) {
		return false;
	}
	++adLoc;
	std::string check, domains;
	for (unsigned i = adLoc; i < email.length(); i++) {
		check += email[i];
	}
	int count = 0;
	std::ifstream domain("./UserData/domain.txt");
	while (getline(domain, domains)) {
		if (check == domains)
			return true;
	}
	return false;
	domain.close();
}
bool Applications::RecoveryEmailCheck()
{
	if (this->RecoveryEmail == "NA" || this->RecoveryEmail == "") {
		return true;
	}
	if (!emailCheck(this->RecoveryEmail)) {
		return false;
	}
	return true;
}
void Applications::emailBasedLog()
{
	do {
		system("cls");
		std::cout << "Enter your name: ";
		getline(std::cin, this->userName);
		std::cout << "Enter your Email address: ";
		getline(std::cin, this->Email);
		std::cout << "Enter your Password: ";
		getline(std::cin, this->password);
		std::cout << "Enter your date of birth(Optional): ";
		getline(std::cin,this-> dateOfBirth);
		std::cout << "Enter your Recovery Email(Optional): ";
		getline(std::cin, this->RecoveryEmail);
		system("cls");
		if (this->userName == "" || this->Email == "NA" || this->password == "NA") {
			std::cout << "Please fill all information correctly";
			getche();
			continue;
		}
		if (!this->emailCheck(Email)) {
			std::cout << "Email Address wrong format";
			getche();
			continue;
		}
		else if (!this->RecoveryEmailCheck()) {
			std::cout << "Recovery Address wrong format";
			getche();
			continue;
		}
		else {
			std::string savePlaceString = "./Explorer/" + this->currentUser + "/Password Saver/Password.txt";
			std::ofstream savePass(savePlaceString,std::ios::app);
			savePass << "User Name: " << this->userName << "\nEmail: " << this->Email << "\nPassword: " << this->password;
			if (this->dateOfBirth != "NA" && dateOfBirth != "") savePass << "\nDate of Birth: " << dateOfBirth;
			if (this->RecoveryEmail != "NA" && this->RecoveryEmail != "") savePass << "\nRecovery Email: " << this->RecoveryEmail;
			savePass << "\n---------------------------\n";
			savePass.close();
			this->saved = true;
			break;
		}
	} while (1);
}
void Applications::phoneBasedLog()
{
	do {
		system("cls");
		std::cout << "Enter your name: ";
		getline(std::cin, this->userName);
		std::cout << "Enter your phone number: ";
		getline(std::cin, this->phoneNumber);
		std::cout << "Enter your Password: ";
		getline(std::cin, this->password);
		std::cout << "Enter your date of birth(Optional): ";
		getline(std::cin, this->dateOfBirth);
		std::cout << "Enter your Recovery Email(Optional): ";
		getline(std::cin, this->RecoveryEmail);
		system("cls");
		if (this->userName == "" || this->phoneNumber == "NA" || this->password == "NA") {
			std::cout << "Please fill all information correctly";
			getche();
			continue;
		}
		if (this->phoneNumber.length() <= 7) {
			std::cout << "Phone Number not valid";
			getche();
			continue;
		}
		else if (!this->RecoveryEmailCheck()) {
			std::cout << "Recovery Address wrong format";
			getche();
			continue;
		}
		else {
			std::string savePlaceString = "./Explorer/" + this->currentUser + "/Password Saver/Password.txt";
			std::ofstream savePass(savePlaceString,std::ios::app);
			savePass << "User Name: " << this->userName << "\nPhone number: " << this->phoneNumber << "\nPassword: " << this->password;
			if (this->dateOfBirth != "NA" && this->dateOfBirth != "") savePass << "\nDate of Birth: " << this->dateOfBirth;
			if (this->RecoveryEmail != "NA" && this->RecoveryEmail != "") savePass << "\nRecovery Email: " << this->RecoveryEmail;
			savePass << "\n---------------------------\n";
			savePass.close();
			this->saved = true;
			break;
		}
	} while (1);
}
void Applications::bothBasedLog()
{
	do {
		system("cls");
		std::cout << "Enter your name: ";
		getline(std::cin, this->userName);
		std::cout << "Enter your Email: ";
		getline(std::cin,this->Email);
		std::cout << "Enter your phone number: ";
		getline(std::cin, this->phoneNumber);
		std::cout << "Enter your Password: ";
		getline(std::cin, this->password);
		std::cout << "Enter your date of birth(Optional): ";
		getline(std::cin, this->dateOfBirth);
		std::cout << "Enter your Recovery Email(Optional): ";
		getline(std::cin,this->RecoveryEmail);
		system("cls");
		if (this->userName == "" || this->Email == "NA" || this->phoneNumber == "NA" || this->password == "NA") {
			std::cout << "Please fill all information correctly";
			getche();
			continue;
		}
		if (this->phoneNumber.length() <= 7) {
			std::cout << "Phone Number not valid";
			getche();
			continue;
		}
		else if (!this->emailCheck(Email)) {
			std::cout << "Email Address wrong format";
			getche();
			continue;
		}
		else if (!this->RecoveryEmailCheck()) {
			std::cout << "Recovery Address wrong format";
			getche();
			continue;
		}
		else {
			std::string savePlaceString = "./Explorer/" + this->currentUser + "/Password Saver/Password.txt";
			std::ofstream savePass(savePlaceString, std::ios::app);
			savePass << "User Name: " << userName << "\nEmail: " << Email << "\nPhone Number: " << phoneNumber << "\nPassword: " << password;
			if (dateOfBirth != "NA" && dateOfBirth != "") savePass << "\nDate of Birth: " << dateOfBirth;
			if (RecoveryEmail != "NA" && RecoveryEmail != "") savePass << "\nRecovery Email: " << RecoveryEmail;
			savePass << "\n---------------------------\n";
			savePass.close();
			saved = true;
			break;
		}
	} while (1);
}
//Password 2.0
void Applications::App_PasswordSaver()
{
	do {
		system("cls");
		std::cout << "------------------" << std::endl;
		std::cout << "|    Password    |" << std::endl;
		std::cout << "------------------" << std::endl;
		std::cout << "E. Email Login\nP. PhoneNumber Login\nT. Both Login\nB. Back\n";
		char dec = getche();
		if (dec == 'E' || dec == 'e') {
			this->emailBasedLog();
		}
		else if (dec == 'P' || dec == 'p') {
			this->phoneBasedLog();
		}
		else if (dec == 'T' || dec == 't') {
			this->bothBasedLog();
		}
		else if (dec == 'B' || dec == 'b') {
			break;
		}
		else {
			continue;
		}
		if (this->saved) {
			this->saved = false;
			std::cout << "Saved Successfully :)";
			getche();
		}
		else {
			std::cerr << "ERROR HOW DID YOU GET HERE :|";
			break;
		}
	} while (1);
}
//Date and Time
void Applications::App_DateAndTime()
{
	system("cls");
	do {
		this->Cls();
		time_t now;
		struct tm nowLocal;
		now = time(NULL);
		nowLocal = *localtime(&now);
		std::cout << "The time right now is: " << nowLocal.tm_hour << ":" << nowLocal.tm_min << ":"
			<< nowLocal.tm_sec << std::endl;
		std::cout << "The date right now is: " << nowLocal.tm_year + 1900 << "/" << nowLocal.tm_mon << "/" << nowLocal.tm_mday << std::endl << "B. Back\n";
		if (_kbhit()){
			if (_getch() == 'B' || _getch() == 'b')
				break;
		}
		Sleep(100);
		if (nowLocal.tm_sec == 0)
			system("cls");
	} while (1);
}
//Calculator
void Applications::calculation(const char oprtr)
{
	system("cls");
	double FN, SN;
	int FN_i, SN_i;
	if (oprtr == 'F') {
		std::cout << "Enter any number: ";
		std::cin >> FN_i;
		std::cout << "Enter another number: ";
		std::cin >> SN_i;
	}
	else {
		std::cout << "Enter any number: ";
		std::cin >> FN;
		std::cout << "Enter another number: ";
		std::cin >> SN;
	}
	switch (oprtr) {
	case 'A':
		std::cout << "The sum is: " << FN + SN;
		_getche();
		break;
	case 'S':
		std::cout << "The difference is: " << FN - SN;
		_getche();
		break;
	case 'M':
		std::cout << "The product is: " << FN * SN;
		_getche();
		break;
	case 'D':
		std::cout << "The quotient is: " << FN / SN;
		_getche();
		break;
	case 'F':
		std::cout << "The remainder is: " << FN_i % SN_i;
		_getche();
		break;
	case 'P':
		std::cout << "The Power raised is: " << pow(FN, SN);
		_getche();
		break;
	case 'R':
		std::cout << "The root is: " << pow(FN, 1 / SN);
		_getche();
		break;
	}
}
void Applications::calculation()
{
	int FN_i;
	double FN, SN;
	do {
		system("cls");
		std::cout << "--------------------\n|    Calculator    |\n--------------------" << std::endl;
		std::cout << "G. Golden Ratio Calculator\nF. Fibonacci Series Calculator\nC. Factorial Calculator\nB. Back" << std::endl;
		char dec = toupper(_getche());
		system("cls");
		if (dec == 'G') {
			std::cout << "Enter the first number in the ratio: ";
			std::cin >> FN;
			std::cout << "Enter the second number in the ratio: ";
			std::cin >> SN;
			if (FN / SN == 1.618)
				std::cout << "The numbers are in golden ratio " << FN / SN;
			else
				std::cout << "The numbers are not in golden ratio " << FN / SN;
			_getche();
			break;
		}
		else if (dec == 'F') {
			std::cout << "Enter the position number of the number in the series you want to find: ";
			std::cin >> FN_i;
			int a = 1, b = 1, c;
			for (int i = 1; i < FN_i; i++) {
				c = a + b;
				a = b;
				b = c;
			}
			std::cout << "The value of the positioned number is: " << a;
			_getch();
			break;
		}
		else if (dec == 'C') {
			std::cout << "Enter the number you want to find fatorial of: ";
			std::cin >> FN_i;
			for (int i = 1; i < FN_i; i++) {
				FN_i *= i;
			}
			std::cout << "The factorial of the number is: " << FN_i;
			_getche();
			break;
		}
		else if (dec == 'B') {
			break;
		}
		else {
			continue;
		}

	} while (1);
}
//Calculations
void Applications::App_Calulator()
{
	do {
		system("cls");
		std::cout << "--------------------\n|    Calculator    |\n--------------------" << std::endl;
		std::cout << "A. Addition\nS. Subtraction\nM. Multiplication\nD. Division\nF. Modulus\nP. Power\nR. Root\nL. Additional Options\nB. Back" << std::endl;
		char dec = toupper(_getche());
		if (dec == 'A') {
			this->calculation('A');
		}
		else if (dec == 'S') {
			this->calculation('S');
		}
		else if (dec == 'M') {
			this->calculation('M');
		}
		else if (dec == 'D') {
			this->calculation('D');
		}
		else if (dec == 'F') {
			this->calculation('F');
		}
		else if (dec == 'P') {
			this->calculation('P');
		}
		else if (dec == 'R') {
			this->calculation('R');
		}
		else if (dec == 'L') {
			this->calculation();
		}
		else if (dec == 'B') {
			break;
		}
		else {
			continue;
		}
	} while (1);
}
//C&D
Applications::Applications(std::string currentUser, std::string currentStatus)
{
	this->currentUser = currentUser;
	this->currentStat = currentStatus;
	this->AppMainMenu();
}
Applications::~Applications()
{
	//...
}