#pragma once
#include "Administrator.h"
#include "N_Administrator.h"
class Admin
{
private:
	std::vector<std::string> userList, userTag, password;
	unsigned userNumber;
	std::string currentUserName, currentUserPassword;
	Administrator* administrator;
	N_Administrator* n_administrator;

	void initUsers();
public:
	//Functions
	void loggingAni();
	void login();
	void loggingIn(bool &administratorBool);
	//C&D
	Admin();
	virtual ~Admin();
};

