#pragma once
class IfReseted
{
private:
	static bool isReset;
public:
	static void init();
	static bool wasReseted();
	static void changeValue(bool value);
};

